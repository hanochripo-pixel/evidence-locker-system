# Claim Red Flags (Engineering)
This file is enforced by G_CLAIM_LADDER_LINT.

## Purpose
Prevent credibility damage by blocking claims that require external proof,
formal certification, or “global uniqueness” assertions we cannot continuously verify.

## Forbidden (hard FAIL)
Any occurrence (case-insensitive) of:
- "the only", "world's only", "唯一", "only solution"
- "compliant", "certified", "approved", "ISO", "NIST compliant" (unless backed by explicit, verifiable evidence artifacts and scoped wording)
- "implements <standard>" for drafts/standards unless strictly true and narrowly scoped

## Allowed (safe patterns)
- "offline-verifiable" when the repository includes:
  - evidence packet fixtures
  - offline verifier gate
  - deterministic replay proof (DOE)
- "fail-closed" when FailPack negative controls prove expected FAIL
- "aligned with" / "mapped to" for SSDF/SLSA, with explicit note:
  "This is not a compliance claim."

## Required outputs for any claim
Claims about security, determinism, or offline verification MUST reference:
- GateTable.md
- PASS receipts for relevant gates
- the exact artifact paths produced by CI
