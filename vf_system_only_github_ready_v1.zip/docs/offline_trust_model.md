# Offline Trust Model (v1)
Offline verification requires a trust bundle that is portable and freshness-checked.

## Trust Root Bundle
trust_root_bundle.json includes:
- schema_version
- bundle_issued_utc (RFC3339)
- bundle_expires_utc (RFC3339)
- max_staleness_days (integer)
- roots[] (opaque entries for v1; structure may evolve)

## Freshness Rules (Fail-Closed)
Verification MUST FAIL if:
- bundle_expires_utc is in the past
- staleness_days > max_staleness_days
- bundle fields are missing/invalid

## Rotation Simulation
G_TRUST_ROOT_ROTATION_SIM uses fixtures under tests/root_rotation_sim to prove:
- fresh case PASS
- stale and expired cases FAIL
- no silent pass
