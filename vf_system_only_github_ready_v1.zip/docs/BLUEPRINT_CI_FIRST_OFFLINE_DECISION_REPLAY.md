# Technical Blueprint — CI-first Offline-Verifiable Policy Decision Replay
Mid-Feb 2026 launch target. Engineering-only blueprint (no marketing, no legal).

## 0. System Intent
Build a CI-first kit that:
1) executes policy-gated decisions deterministically,
2) produces audit-grade evidence artifacts,
3) supports offline verification and offline deterministic replay of PASS/FAIL,
4) evolves in controlled, fail-closed increments.

Core Chain (canonical):
spec → policy → execution → measurement → identity lock → controlled evolution

---

## 1. Architectural Overview (Layers)
### 1.1 Spec Layer (Contracts)
Defines what MUST be true to claim a decision is valid:
- minimum evidence set
- schemas for EvidencePacket / DecisionRecord / Metrics / FailPack
- canonicalization requirements
- reason-code taxonomy + deterministic ordering rules
- subgraph binding rules (decision ↔ exact evidence subset)

### 1.2 Policy Layer
Machine-enforceable rules:
- policy pack version pinned
- staleness/refresh rules for trust roots
- thresholds and forbidden states (fail-closed)

### 1.3 Execution Layer
Deterministic runners:
- PowerShell (pwsh 7.x) canonical runner for Windows + CI parity
- Strict stop-on-blocker behavior; no “silent pass”

### 1.4 Measurement Layer
Standard reporting + canonical decision substrate:
- SARIF for reporting envelope
- Canonical JSON summaries for decision substrate (deterministic)
- Metrics report per fixture run

### 1.5 Identity Lock Layer
Tamper-evident artifact binding:
- sha256 for every artifact
- manifest.json + manifest.sha256 (outer)
- receipts (run receipts, verify receipts)
- repo snapshot (file list + sha256) + receipt

### 1.6 Controlled Evolution Layer
Every change is:
- small (One-NEXT = one commit / one patchpack)
- evidence-backed (receipts + snapshot)
- regression-guarded (goldens + FailPack negative suite)
- reversible (backup/rollback plan)

---

## 2. Repo Layout (Target)
```
/docs/
  BLUEPRINT_CI_FIRST_OFFLINE_DECISION_REPLAY.md
  evidence_contract.md
  determinism_doe.md
  offline_trust_model.md
  sarif_mapping.md
  quickstart.md
  troubleshooting.md
  claim_red_flags.md
  standards_language.md
  ssdf_alignment.md
  slsa_alignment.md
  versioning_policy.md
  conformance_rules.md
  conformance_badge_policy.md
  integration_opa.md
/contracts/
  contract_index.json
/policies/
  policy_pack.yaml
/schemas/
  evidence_packet.schema.json
  decision_record.schema.json
  metrics_report.schema.json
  failpack_manifest.schema.json
  trust_root_bundle.schema.json
/samples/
  fixtures/
    pass_packet_min.zip
    failpack/
      mutations/*.zip
/tests/
  root_rotation_sim/*
/scripts/
  lib/VF_LIB.ps1
  gates/
    RUN_0P_GATES.ps1
    0p/*.ps1
/.github/workflows/
  vf_0p_gates.yml
  scorecard.yml
/logs/            (runtime, gitignored)
/receipts/        (runtime, gitignored)
/artifacts/        (runtime outputs, gitignored)
```

Notes:
- `/logs`, `/receipts`, `/artifacts` are outputs (gitignored).
- Schemas, policies, and fixtures are committed (deterministic test surface).

---

## 3. Minimal End-to-End Slice (CI-first)
### Inputs
- one fixture PASS packet
- one FailPack set (negative controls)
- one SARIF output

### Flow
1) Validate EvidencePacket contract
2) Validate trust bundle freshness/rotation rules
3) Validate SARIF envelope
4) Prove determinism (DOE)
5) Prove fail-closed (FailPack)
6) Identity lock: sha256 + receipts + repo snapshot

---

## 4. Launch-Readiness (0P thresholds)
Hard thresholds before public release:
- CI hardened for the release workflow(s)
- Evidence contract validates offline without network
- Determinism DOE is stable (no drift)
- FailPack negative controls fail as expected
- TTFP proof ≤ policy threshold
- No forbidden claims in docs/README
- Repo health files present (SECURITY/CONTRIBUTING/CoC/LICENSE/TRADEMARK)

---

## 5. Non-Goals (v1)
- “Compliance” claims (SSDF/SLSA) — only mapping/alignment documents with traceability artifacts.
- Full signing infrastructure — evidence-first, offline replay-first.

---

## 6. Delta Additions (Required to match Research Pack)
### Repo Layout additions
- /GateTable.md
- /docs/claim_red_flags.md
- /docs/standards_language.md
- /docs/ssdf_alignment.md
- /docs/slsa_alignment.md
- /docs/versioning_policy.md
- /docs/conformance_rules.md
- /docs/conformance_badge_policy.md
- /docs/integration_opa.md
- /tests/root_rotation_sim/
- /samples/fixtures/failpack/mutations/
- /artifacts/ttfp/ (generated; gitignored)

### Root-level trust signals (required files)
- SECURITY.md
- CONTRIBUTING.md
- CODE_OF_CONDUCT.md
- LICENSE
- TRADEMARK.md
- .github/ISSUE_TEMPLATE/
- PULL_REQUEST_TEMPLATE.md

### Gate additions (fail-closed)
- G_LAUNCH_GATE_0P (meta gate: asserts all 0P artifacts exist + PASS)
- G_CLAIM_LADDER_LINT (blocks forbidden phrases / unsafe “firstness” claims)
- G_TRUST_ROOT_ROTATION_SIM (proves no silent pass under rotation/staleness)
- G_TTFP_PROOF (asserts ≤15-min path produces required artifacts)
