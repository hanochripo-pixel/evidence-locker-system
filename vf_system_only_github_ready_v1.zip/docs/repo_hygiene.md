# Repo Hygiene (v1)
Goal: prevent runtime outputs from contaminating commits.

## Outputs (must be ignored)
- logs/
- receipts/
- artifacts/
- backups/
