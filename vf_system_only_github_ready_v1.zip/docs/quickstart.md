# Quickstart (0P Gates)
Goal: produce PASS receipts for all 0P gates in <= 15 minutes on a clean checkout.

## Prereqs
- PowerShell 7.x installed (pwsh)
- Run from repo root

## Run (local)
pwsh -NoProfile -ExecutionPolicy Bypass -File scripts/gates/RUN_0P_GATES.ps1 -RepoRoot .

## Outputs
- logs/*.latest.(txt|json)
- receipts/*.latest.json
- artifacts/metrics/determinism_doe.latest.json
- artifacts/trust/trust_rotation_sim.latest.json
- artifacts/failpack/failpack_report.latest.json
- artifacts/ttfp/ttfp_proof.latest.json

## CI
Workflows:
- .github/workflows/vf_0p_gates.yml
- .github/workflows/scorecard.yml
