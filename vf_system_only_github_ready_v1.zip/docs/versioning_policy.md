# Versioning Policy (v1)
We use SemVer for the public kit surface.

## Major (X.0.0)
- breaking schema change
- breaking gate contract change (inputs/outputs/reason codes)
- breaking CLI/API behavior change

## Minor (0.Y.0)
- new gates added
- new optional fields in schemas (backwards compatible)
- improved fixtures

## Patch (0.0.Z)
- bug fixes
- documentation fixes
- tightening validations without breaking existing valid artifacts

## 0P naming freeze (P0)
- The following prefixes are **reserved and frozen**: `VERIFY_08C_*`, `VERIFY_09A_*`, `G_FAILPACK_*`.
- Do not repurpose or change semantics under frozen prefixes without a **Major** version bump.
- New gates MUST use new IDs (never overload an existing identifier).
