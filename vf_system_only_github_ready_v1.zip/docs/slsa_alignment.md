# SLSA Alignment (Mapping Only)
This document maps repository evidence to supply-chain expectations.
This is NOT a compliance claim.

## What we provide (v1)
- deterministic evidence artifacts (offline verifiable)
- immutable digests for artifacts
- workflow hardening checks (pinned actions policy where applicable)

## Future (post-launch)
- provenance generation and signing
- policy-verified builder identity
