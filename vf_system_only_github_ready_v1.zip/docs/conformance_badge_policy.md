# Conformance Badge Policy (v1, Planned)
Badges must be evidence-backed.

## Rules
- badges are derived from PASS receipts
- badge must include the exact gate set and version
- no badge if any 0P gate is missing or FAIL
