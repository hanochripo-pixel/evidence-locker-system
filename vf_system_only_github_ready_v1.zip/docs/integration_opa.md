# OPA Integration (Optional, Post-Launch)
OPA/Rego can be added as a policy engine.

## v1 stance
- Policy is expressed as enforceable gate contracts + deterministic scripts.
- OPA integration is optional and MUST NOT break offline verification.

## v2 direction
- compile Rego to WASM
- pin policy pack versions and digests
- record policy evaluation evidence into DecisionRecord
