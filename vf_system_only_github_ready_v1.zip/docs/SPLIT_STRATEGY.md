# Split Strategy (Public vs Private) — v1
This document is technical and operational. It defines what belongs in the public community repo vs a private core repo.

## Public (community) repo owns
- **Contracts**: schemas, file formats, receipt structure.
- **Scaffold**: non-sensitive gates and CI integration.
- **Fixtures**: minimal pass packet + failpack mutations.
- **Transparency**: deterministic receipts and explainable failure reasons.

## Private (core) repo owns
- **Policy packs** beyond public contract surface.
- **Advanced verifiers** (multi-stage, proprietary heuristics).
- **Commercial packaging** (registry, licensing, premium distributions).
- **Proprietary claim ladder layers** (brand-critical assertions and threat models).

## Boundary rules
- Public MUST run end-to-end with fixtures (no private dependency).
- Private MAY import public as a git submodule/subtree or as a packaged release.
- Private MUST NOT require public to accept sensitive keys or tokens.

## Integration patterns
- **Submodule**: private pins public at a commit.
- **Subtree**: private vendors public to reduce tooling friction.
- **Package**: private consumes public as a versioned artifact (zip/nuget/pypi).
