# Troubleshooting (v1)

## Gate fails because "Not CI context"
Some gates are CI-only. Run them in GitHub Actions, or pass -AllowLocal if supported.

## Line endings / encoding drift
All committed text should be LF and UTF-8 (no BOM). Avoid editors that rewrite line endings.

## Missing files
Run:
- git status
- confirm required docs and schemas exist
- confirm fixtures exist under samples/fixtures and tests/root_rotation_sim

## Baseline mismatch
If PATCHPACK_VERIFY_ONLY reports baseline hash mismatch, restore baseline first and re-run.
