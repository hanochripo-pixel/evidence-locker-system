# Conformance Rules (v1, Planned)
Defines how external runners can claim they conform to the kit.

## Minimum conformance
- can run 0P gates
- can produce required artifacts
- determinism DOE is stable
- failpack negatives fail as expected

## Proof format
- provide receipts + logs
- provide repo snapshot or equivalent identity lock artifact
