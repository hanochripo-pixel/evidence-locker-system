# DoD — DONE-SYSTEM (Normative)

DONE-SYSTEM is satisfied **iff**:

1) Local run:
   - `pwsh -NoProfile -ExecutionPolicy Bypass -File scripts/gates/RUN_0P_GATES_SYSTEM.ps1 -RepoRoot .`
   finishes with **PASS**.

2) Receipts exist + PASS:
   - `receipts/receipt_g_launch_gate_system_0p.latest.json` exists and has `status == "PASS"`.

3) Fail-closed proof:
   - FailPack gates PASS (they must demonstrate that expected-bad inputs FAIL with the expected reason codes).

4) CI parity:
   - GitHub Actions workflow `vf-system-0p-gates` runs the same SYSTEM runner on PR/push and must PASS.

Notes:
- This repo variant intentionally excludes any paper/AE pipeline.
- Generated outputs (`logs/`, `receipts/`, `artifacts/`) are runtime outputs and are ignored by git.
