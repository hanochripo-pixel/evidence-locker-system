# Standards Language (Engineering)
This file is enforced by G_CLAIM_LADDER_LINT.

## Goal
Use precise language around standards to avoid accidental misrepresentation.

## Safe vocabulary
- "aligned with" — we map our artifacts to a standard's intent
- "mapped to" — we provide traceability, not certification
- "supports" — we enable a workflow compatible with a concept
- "implements" — only if we implement a published normative spec in full (and have tests)

## Forbidden vocabulary (unless strictly true + scoped)
- "compliant", "certified", "approved"
- "implements" when only a partial mapping exists
- "the only / first / unique" without a continuously verifiable public benchmark

## Required repository evidence for any standards mention
- docs/ssdf_alignment.md (mapping, no compliance claim)
- docs/slsa_alignment.md (mapping, no compliance claim)
- GateTable.md + PASS receipts for the relevant artifact producers
