# Triple-Core Split (Repo-Core / Paper-Core / Interface-Contract) — v1

This document defines the internal split inside this repository.
It is operational: it binds ownership, CI, and meta-gates to preserve fail-closed behavior.

## Cores

### Interface-Contract (IC)
Owns:
- `GateTable.md`
- `contracts/**`
- `schemas/**`
- contract-facing docs: trust model, evidence contract, standards language, versioning policy

### Repo-Core (RC)
Owns:
- `.github/**`
- `scripts/**`
- `samples/**`
- `tests/**`
- repo operational docs (quickstart/troubleshooting/repo hygiene)

### Paper-Core (PC)
Owns:
- `docs/paper/**`
- `ae/**`
- `out/**`
- `artifacts/metrics/**`

## CI split (0P)
- Repo-Core CI runs: `scripts/gates/RUN_0P_GATES_REPOCORE.ps1`
- Paper-Core CI runs: `scripts/gates/RUN_0P_GATES_PAPERCORE.ps1`

## Meta gates
- `G_LAUNCH_GATE_REPOCORE_0P`: requires Repo-Core receipt set only
- `G_LAUNCH_GATE_PAPERCORE_0P`: requires Paper-Core receipt set only
- `G_LAUNCH_GATE_0P`: remains the integrated full-run meta gate (optional / integration)

## External PDFs policy (Paper-Core)
Paper-Core does not store third-party PDFs publicly.
Instead: bibliography + hash ledger at `docs/paper/external_sources_hashes.json`.
