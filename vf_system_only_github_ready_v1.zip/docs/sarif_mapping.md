# SARIF Mapping (v1)
SARIF is the reporting envelope. The decision substrate remains in canonical JSON.

## Minimal requirements (v1)
results.sarif MUST be valid JSON and contain:
- "version"
- "runs" array with at least one element
- runs[0].tool.driver.name
- runs[0].results (may be empty, but field must exist)

## Enforcement
G_SARIF_VALIDATE performs minimal structure validation.
This is not a full schema compliance claim.
