# Evidence Contract (Minimum Set)
This repository is evidence-first. Claims are backed by deterministic artifacts.

## Minimum Evidence Set (v1)
An EvidencePacket ZIP MUST contain:
- evidence_packet.json
- decision_record.json
- trust_root_bundle.json
- sarif/results.sarif
- packet.manifest.json  (lists paths + sha256 for all files inside the packet)

## Packet Identity
- packet_id is defined as sha256(packet.manifest.json bytes)
- All sha256 values are lowercase hex.

## Determinism Rules
- UTF-8 (no BOM), LF line endings
- Paths in manifests use forward slashes
- Reason codes are deterministically ordered (see GateTable.md)

## Offline Verification
Offline verification MUST NOT require network access.
Trust freshness is validated using trust_root_bundle.json and policy thresholds.

## Enforcement
- G_EVIDENCE_CONTRACT_VALIDATE enforces structure + required fields.
- VERIFY_08C_PACK_STRICT enforces outer ZIP/manifest sha integrity (where applicable).
