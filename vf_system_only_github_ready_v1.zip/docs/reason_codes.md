# reason_codes.md

Canonical reason-code taxonomy and deterministic ordering keys.

> Normative: reason ids and `stable_sort_key` are fixed for 0P.

| reason_id | stable_sort_key | category | severity | description |
|---|---:|---|---|---|
| FAIL_MISSING_INPUT | 10 | input | HIGH | Required file/input is missing; MUST be FAIL-closed. |
| FAIL_SCHEMA_INVALID | 20 | schema | HIGH | Input/sidecar JSON (or sha file) is unparsable or violates schema/contract. |
| FAIL_SHA256_MISMATCH | 30 | crypto | HIGH | SHA-256 binding mismatch (zip/manifest/member). |
| FAIL_POLICY_VIOLATION | 40 | policy | HIGH | Policy contract violated (forbidden mode, missing required evidence, etc.). |
| FAIL_DETERMINISM_DRIFT | 50 | determinism | HIGH | Same inputs yield different outputs/reasons across reruns/platforms. |
| FAIL_DANGEROUS_WORKFLOW | 60 | workflow | HIGH | Dangerous CI/workflow pattern detected (un-pinned actions, risky permissions, etc.). |
| FAIL_FORBIDDEN_CLAIM | 70 | claims | MED | Docs contain forbidden / overclaim phrasing. |
| FAIL_TRUST_BUNDLE_STALE | 80 | trust | HIGH | Trust bundle expired or outside max staleness window. |
| FAIL_TTFP_EXCEEDED | 90 | operability | MED | Time-to-first-proof budget exceeded. |
| FAIL_UNEXPECTED_PASS | 100 | oracle | HIGH | Negative control (FailPack) unexpectedly passed. |
| FAIL_UNEXPECTED_FAIL | 110 | oracle | HIGH | Baseline control unexpectedly failed. |
| FAIL_NOT_CI_CONTEXT | 120 | workflow | MED | Gate is CI-only but was run outside CI context. |
| FAIL_TOOLCHAIN_UNPINNED | 130 | workflow | HIGH | Toolchain version is unpinned or ambiguous in a way that breaks reproducibility. |
