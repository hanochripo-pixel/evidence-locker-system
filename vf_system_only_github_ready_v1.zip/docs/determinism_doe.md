# Determinism DOE (Design of Experiments)
Determinism is proven empirically via repeated runs on the same inputs.

## What is measured
- stable digests for evidence artifacts across re-runs
- stable reason-code ordering
- stable PASS/FAIL outcomes

## Failure definition
Any drift in:
- computed sha256 of canonical artifacts
- reason code sequence
- PASS/FAIL result

## Enforcement
G_DETERMINISM_DOE:
- runs the same contract validations multiple times
- compares stable digests and stable reason ordering
- emits artifacts/metrics/determinism_doe.latest.json
