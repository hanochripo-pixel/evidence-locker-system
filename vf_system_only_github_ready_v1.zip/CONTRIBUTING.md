# Contributing

## Principles
- Small changes (one logical change per PR)
- Evidence-backed changes (receipts + tests where applicable)
- Deterministic outputs (no nondeterministic formatting)

## Pull Requests
- Describe intent and touched paths
- Include how to reproduce
- Ensure 0P gates pass (see docs/quickstart.md)

## Code of Conduct
See CODE_OF_CONDUCT.md.

## Maintainer contact
Hanoch Reider — hanoch@evidence-locker.net
