# GateTable.md
Engineering-only Gate Table for a CI-first, offline-verifiable, **fail-closed** SYSTEM.

This file is **normative**: implementations MUST match these contracts.
The goal is enforceability (receipts + deterministic outputs), not a checklist.

---

## Scope (SYSTEM-only)

This repository enforces **SYSTEM DoD** only.
Academic / paper / AE concerns are explicitly out-of-scope for this repo variant.

---

## Conventions (Normative)

### Execution
- Runner: PowerShell 7.x (`pwsh`).
- Gates/verifiers MUST be runnable locally unless explicitly marked CI-only.
- Gates/verifiers MUST be fail-closed (any uncertainty ⇒ FAIL).

### Outputs (Canonical)
Each gate/verifier MUST emit:
- `logs/<GATE_ID>.latest.txt`
- `logs/<GATE_ID>.latest.json`
- `receipts/<receipt_id>.latest.json`

### Naming (Frozen prefixes)
- Naming is frozen for: `PRE_00*`, `VERIFY_08C_*`, `VERIFY_09A_*`, `VF_REPO_SNAPSHOT_*`, `G_FAILPACK_*`.

---

## Gate Index (Normative)

| Gate ID | Type | Purpose | Primary script |
|---|---:|---|---|
| PRE_00_RUNTIME_CONTRACT | Preflight | Fail-closed runtime/toolchain baseline (pwsh, platform, locale constraints). | `scripts/preflight/PRE_00_RUNTIME_CONTRACT.ps1` |
| PRE_00 | Preflight | Repo baseline checks + required directory structure. | `scripts/preflight/PRE_00.ps1` |
| VERIFY_08C_PACK_STRICT | Verifier | Offline verify EvidencePack: `zip + manifest + sha sidecars` (parse only after sha). | `scripts/verify/VERIFY_08C_pack_offline_verify_strict.ps1` |
| VERIFY_09A_PACKET_CONTRACT_OFFLINE | Verifier | Offline verify EvidencePacket contract inside an EvidencePacket zip. | `scripts/verify/VERIFY_09A_packet_contract_offline.ps1` |
| VERIFY_09A_POLICY_SPEC | Verifier | Verify public policy_spec contract surface. | `scripts/verify/VERIFY_09A_policy_spec.ps1` |
| VF_REPO_SNAPSHOT_00 | Snapshot | Deterministic repo inventory snapshot for traceability. | `scripts/snapshot/VF_REPO_SNAPSHOT_00.ps1` |
| G_REPO_HEALTH_FILES_ASSERT | Gate | Governance/trust baseline files exist (LICENSE/SECURITY/README/etc.). | `scripts/gates/0p/G_REPO_HEALTH_FILES_ASSERT.ps1` |
| G_CI_HARDENING_ASSERT | Gate (CI-aware) | Enforce safe workflow patterns, pinned actions, explicit permissions. | `scripts/gates/0p/G_CI_HARDENING_ASSERT.ps1` |
| G_SCORECARD_ASSERT | Gate (CI-aware) | Assert presence/config of Scorecard workflow (baseline posture). | `scripts/gates/0p/G_SCORECARD_ASSERT.ps1` |
| G_CLAIM_LADDER_LINT | Gate | Lint/consistency checks for claim ladder conventions (SYSTEM-level). | `scripts/gates/0p/G_CLAIM_LADDER_LINT.ps1` |
| G_EVIDENCE_CONTRACT_VALIDATE | Gate | Validate pass-packet fixture against schemas + contract rules. | `scripts/gates/0p/G_EVIDENCE_CONTRACT_VALIDATE.ps1` |
| G_SARIF_VALIDATE | Gate | Validate SARIF fixtures (structure + minimal invariants). | `scripts/gates/0p/G_SARIF_VALIDATE.ps1` |
| G_TRUST_ROOT_ROTATION_SIM | Gate | Rotation/staleness simulation must fail-closed when stale/expired. | `scripts/gates/0p/G_TRUST_ROOT_ROTATION_SIM.ps1` |
| G_DETERMINISM_DOE | Gate | Determinism “DOE” check: repeated runs must match canonical outputs. | `scripts/gates/0p/G_DETERMINISM_DOE.ps1` |
| G_FAILPACK_RUN_MIN | Gate | Negative controls for pack verification (VERIFY_08C) must fail correctly. | `scripts/gates/0p/G_FAILPACK_RUN_MIN.ps1` |
| G_FAILPACK_RUN_CONTRACT_MIN | Gate | Negative controls for packet contract verification (VERIFY_09A) must fail correctly. | `scripts/gates/0p/G_FAILPACK_RUN_CONTRACT_MIN.ps1` |
| G_TTFP_PROOF | Gate | “Time-to-first-proof” proof object is emitted and validated. | `scripts/gates/0p/G_TTFP_PROOF.ps1` |
| G_LAUNCH_GATE_SYSTEM_0P | Meta Gate | Asserts required receipts exist and are PASS (SYSTEM DoD). | `scripts/gates/0p/G_LAUNCH_GATE_SYSTEM_0P.ps1` |

---

## SYSTEM DoD (Normative)
SYSTEM is **DONE** iff `scripts/gates/RUN_0P_GATES_SYSTEM.ps1` finishes PASS and `G_LAUNCH_GATE_SYSTEM_0P` is PASS.
