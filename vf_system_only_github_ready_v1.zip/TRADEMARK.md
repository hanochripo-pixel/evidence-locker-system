# Trademark
Project and product names may be trademarked or otherwise protected.

## Policy (v1)
- Do not use the project name to imply endorsement without permission.
- Forks must clearly distinguish branding.
