# Code of Conduct
This project expects professional, respectful collaboration.

We follow the spirit of the Contributor Covenant:
- be respectful
- assume good faith
- focus on technical substance
