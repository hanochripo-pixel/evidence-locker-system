# VF Community CI Kit (vNext / FailPack v2)
A community-facing, CI-first repo seed for an offline-verifiable “evidence packet” workflow.

This repository is intentionally **limited**:
- It provides **scaffolding**, fixtures, and non-sensitive 0P gates.
- It does **not** include private policy packs, advanced verifiers, or proprietary claim-ladder layers.

## What you get

## SYSTEM focus (this repo variant)
This repository variant is **SYSTEM-only**: it enforces DONE-SYSTEM and intentionally excludes any paper/AE pipeline.

### Quickstart
```bash
pwsh -NoProfile -ExecutionPolicy Bypass -File scripts/gates/RUN_0P_GATES_SYSTEM.ps1 -RepoRoot .
```

### DONE-SYSTEM
See `docs/DOD_SYSTEM.md` and the normative gate index in `GateTable.md`.

- A minimal **0P GatePack** that can run locally (PowerShell 7) and in CI.
- An **offline verification** pattern for evidence packs (**zip + manifest + sha sidecars**) via `VERIFY_08C_pack_offline_verify_strict`.
- A **FailPack v2** negative-control suite (manifest-driven) proving the verifier fails closed.
- A minimal **SARIF** envelope validation gate.
- Determinism and launch gates.
- A hardened baseline for GitHub Actions and OpenSSF Scorecard.

## Core specs
- `GateTable.md` (engineering gate contract)
- `docs/GateTable_vNext_FAILPACK_v2_20260223.pdf` (reference PDF)
- `schemas/failpack_manifest.schema.json` (schema v2)
- `samples/fixtures/failpack/failpack_manifest.json` (suite instance)

## Canonical line (Repo-Now)
- This repo is the canonical **Repo-Now** line (superset baseline for the public contract surface).
- Naming is frozen for: `VERIFY_08C_*`, `VERIFY_09A_*`, `G_FAILPACK_*`.


## What stays private (by design)
- Policy packs beyond the public contract surface.
- Advanced verifiers (multi-stage, proprietary checks).
- Packaging/registry code for commercial distribution.

## Quickstart (local)
Prereqs:
- PowerShell 7 (`pwsh`)

Run 0P gates:
```powershell
pwsh -NoProfile -ExecutionPolicy Bypass -File .\scripts\gates\RUN_0P_GATES.ps1 -RepoRoot (Get-Location).Path
```

## Quickstart (CI)
See:
- `.github/workflows/vf_0p_gates.yml`
- `.github/workflows/scorecard.yml`

## Professional stance (claims)
This repo avoids “world-first” or “only one” claims.
See `docs/standards_language.md` and `docs/claim_red_flags.md`.

## Maintainer
Hanoch Reider — hanoch@evidence-locker.net

## License
Apache-2.0 (see `LICENSE`).