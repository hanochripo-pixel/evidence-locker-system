# Pragmatic Agent Engineering Guidance (PAEG)
Version: v1
Status: NORMATIVE
Last-Updated-UTC: 2026-02-25T10:16:04Z

Purpose:
- This document is the single source of truth for how AI agents and operators must produce repo changes.
- It operationalizes: ETC/DRY/Tracer Bullets/Plain Text/Version Control/Design by Contract/Crash Early.
- It binds the repo to an evidence-first, fail-closed execution model: spec -> policy -> execution -> measurement -> identity lock -> controlled evolution.

Non-Negotiables (each item is a contract ID):

PAEG-01: Stop Conditions / No Guessing
- If an input/anchor/evidence is missing: STOP with FAIL. No assumptions, no silent fallback.

PAEG-02: Fail-Closed Always
- PASS is allowed only when all required checks pass. Any stop_reasons => FAIL.

PAEG-03: Evidence-First Outputs
- Every DISCOVERY/PATCH/VERIFY writes: logs/<id>.txt + logs/<id>.json + receipts/<id>.json with sha256.

PAEG-04: One NEXT = One Change = One Commit
- One patch scope per commit. Minimize blast-radius.

PAEG-05: Plain Text Default
- Policies, contracts, receipts, and maps must be readable/searchable text by default.

PAEG-06: Automation Over Heroism
- If you do it twice, automate it. Manual steps must be eliminated or turned into scripts.

PAEG-07: Runtime Contract (Shell Determinism)
- No hardcoded 'powershell' spawns unless allowlisted. Prefer pwsh, and prove the runtime via discovery.

PAEG-08: Paste-to-Terminal Safety
- No nested here-strings. No GitHub Actions logs pasted as commands.
- Any line containing `${{` must be emitted as literal text (never PowerShell interpolation).

PAEG-09: Standard Work Units
- DISCOVERY: truth map only (no changes).
- PATCH: one change, idempotent, backups, sha before/after, fail-closed.
- VERIFY: independent checker, produces receipts.

PAEG-10: DoD (Definition of Done) Levels
- DoD-1: artifacts written; DoD-2: receipts+sha; DoD-3: verifier passes offline; DoD-4: local+CI reproduce.

PAEG-11: CI Must Enforce Preflight
- PRE_00 (runtime contract + policy gate) must run in CI before other steps.

PAEG-12: Git Hygiene (Evidence Isolation)
- Evidence outputs must be isolated via .gitignore policy; commits must stage only intended paths.

PAEG-13: Security Baseline
- Minimum: SSDF-aligned secure SDLC and OWASP LLM risk awareness for agentic workflows.

PAEG-14: Reversibility
- Prefer reversible decisions (adapters, config, small commits). Avoid lock-in and irreversible edits.

PAEG-15: DRY / Single Source of Truth
- No duplicated 'truth'. One authoritative file/contract per concept, others derived.

PAEG-16: Orthogonality
- Changes should not force unrelated changes. If they do, reduce coupling.

PAEG-17: Tracer Bullets
- Prefer end-to-end thin slices to validate integration early.

PAEG-18: Design by Contract
- Preconditions/Postconditions/Invariants are explicit and verified. Dead programs tell no lies.

PAEG-19: Measurement is a Product Feature
- Every critical decision produces measurable evidence (sha, receipts, reports).

PAEG-20: Controlled Evolution
- No change without a migration plan and a verifier that enforces it.

References (non-normative):
- The Pragmatic Programmer, 20th Anniversary Edition (topics: Plain Text, Version Control, Tracer Bullets, Design by Contract, Dead Programs Tell No Lies).
- NIST SP 800-218 SSDF (secure SDLC baseline).
- OWASP Top 10 for LLM Applications (agentic AI risk baseline).
