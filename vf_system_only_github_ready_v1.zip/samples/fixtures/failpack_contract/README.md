# FailPack (evidence contract)

This directory contains a **FailPack** suite of *internal* EvidencePacket mutations that are intended to exercise the **evidence contract gate** (`G_EVIDENCE_CONTRACT_VALIDATE`).

This suite is intentionally **not** a replacement for the existing FailPack under `../failpack/` (which targets `VERIFY_08C` sidecar integrity: zip/manifest/sha).

## What’s here

- `failpack_manifest.contract.json` – schema v2 manifest describing contract-layer negative controls
- `mutations/` – pre-materialized mutated EvidencePacket zips (+ sidecars)

## Scope / intent

- Mutations operate **inside the EvidencePacket zip** (e.g., missing `decision_record.json`, corrupted JSON, `packet_id` binding break).
- For most cases, the **sidecars are kept internally consistent** (`.zip.sha256`, `.manifest.json`, `.manifest.sha256`) so that `VERIFY_08C` is not the reason for failure if it is run separately.

## How it’s used

The gate script `scripts/gates/0p/G_FAILPACK_RUN_CONTRACT_MIN.ps1`:

1. Verifies the baseline PASS pack via `scripts/verify/VERIFY_09A_packet_contract_offline.ps1`
2. Runs each FailPack case from `failpack_manifest.contract.json`
3. Writes `artifacts/failpack/failpack_contract_report.latest.json`

A green run requires:

- baseline PASS
- every case FAILs with the expected reason code(s)
- coverage == 1.0
- all required `coverage_targets` are satisfied by at least one OK case
