# FailPack fixtures

This directory contains a **FailPack**: a small, deterministic suite of *negative-control* fixtures used to prove that the offline verifier fails closed.

## What’s here

- `failpack_manifest.json` – the authoritative list of test cases (schema v2)
- `mutations/` – pre-materialized mutated packs referenced by the manifest

The baseline PASS pack is **not** in this directory:

- `../pass_packet_min.zip`
- `../pass_packet_min.zip.sha256`
- `../pass_packet_min.manifest.json`
- `../pass_packet_min.manifest.sha256`

## How it’s used

The gate script `scripts/gates/0p/G_FAILPACK_RUN_MIN.ps1`:

1. Verifies the baseline PASS pack via `scripts/verify/VERIFY_08C_pack_offline_verify_strict.ps1`
2. Runs each FailPack case from `failpack_manifest.json`
3. Writes `artifacts/failpack/failpack_report.latest.json`

A green run requires:

- baseline PASS
- every case FAILs with the expected reason code(s)
- coverage == 1.0
- all required `coverage_targets` are satisfied by at least one OK case



---

See also: `samples/fixtures/failpack_contract/` for contract-layer FailPack targeting `G_EVIDENCE_CONTRACT_VALIDATE`.
