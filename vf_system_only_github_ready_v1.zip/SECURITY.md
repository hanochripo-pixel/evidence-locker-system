# Security Policy

## Reporting a Vulnerability
If you believe you have found a security vulnerability, please use one of:
1) GitHub Security Advisories (preferred, private disclosure), if enabled.
2) Contact the maintainer privately: Hanoch Reider <hanoch@evidence-locker.net>.

Please do NOT open a public issue for active vulnerabilities.

## Scope
This project is evidence-first and fail-closed by design, but no security claims are made without explicit, reproducible artifacts.
