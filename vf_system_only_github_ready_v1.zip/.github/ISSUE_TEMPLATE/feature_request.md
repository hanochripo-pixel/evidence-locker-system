---
name: Feature request
about: Suggest an enhancement
---

## Problem
## Proposed solution
## Evidence / justification
