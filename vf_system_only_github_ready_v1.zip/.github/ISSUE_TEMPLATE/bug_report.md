---
name: Bug report
about: Report a bug
---

## What happened?
## What did you expect?
## Reproduction steps
## Logs / receipts (attach paths)
