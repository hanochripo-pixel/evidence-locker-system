param(
  [Parameter(Mandatory=$true)][string]$RepoRoot
)

. (Join-Path $RepoRoot "scripts/lib/VF_LIB.ps1")

$gateId = "G_REPO_HEALTH_FILES_ASSERT"
$receiptId = "receipt_g_repo_health_files_assert"
$p = VF-NewGatePaths $RepoRoot $gateId $receiptId
$ts = VF-NowUtc

$required = @(
  "SECURITY.md",
  "CONTRIBUTING.md",
  "CODE_OF_CONDUCT.md",
  "LICENSE",
  "TRADEMARK.md",
  "PULL_REQUEST_TEMPLATE.md",
  ".github/ISSUE_TEMPLATE/bug_report.md",
  ".github/ISSUE_TEMPLATE/feature_request.md"
)

$missing = @()
foreach($r in $required){
  $full = Join-Path $RepoRoot $r
  if(-not (Test-Path -LiteralPath $full -PathType Leaf)){
    $missing += $r
  }
}

$status = "PASS"
$stop = @()
if($missing.Count -gt 0){
  $status = "FAIL"
  foreach($m in $missing){ $stop += ("FAIL_MISSING_INPUT: missing {0}" -f $m) }
}

$doc = [ordered]@{
  schema_version = 1
  kind = $gateId
  created_utc = $ts
  status = $status
  stop_reasons = @($stop)
  metrics = [ordered]@{
    present_count = ($required.Count - $missing.Count)
    missing_count = $missing.Count
  }
}

VF-WriteJson $p.outJson $doc 50

$txt = @()
$txt += $gateId
$txt += "created_utc=$ts"
$txt += "status=$status"
if($missing.Count -gt 0){
  $txt += ""
  $txt += "missing:"
  foreach($m in $missing){ $txt += ("  - " + $m) }
}
VF-WriteText $p.outTxt ($txt -join "`n")

$outs = [ordered]@{
  txt = $p.outTxt
  json = $p.outJson
  txt_sha256 = (VF-Sha256 $p.outTxt)
  json_sha256 = (VF-Sha256 $p.outJson)
}
VF-EmitReceipt $p.outRcpt "receipt_gate" $status @{ repo_root=$RepoRoot } $outs

if($status -ne "PASS"){ exit 2 }
exit 0
