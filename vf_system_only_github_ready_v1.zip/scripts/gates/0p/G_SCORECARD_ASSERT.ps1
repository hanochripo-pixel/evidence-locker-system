param(
  [Parameter(Mandatory=$true)][string]$RepoRoot,
  [Parameter(Mandatory=$false)][switch]$AllowLocal
)

. (Join-Path $RepoRoot "scripts/lib/VF_LIB.ps1")

$gateId = "G_SCORECARD_ASSERT"
$receiptId = "receipt_g_scorecard_assert"
$p = VF-NewGatePaths $RepoRoot $gateId $receiptId
$ts = VF-NowUtc

$stop = New-Object System.Collections.Generic.List[string]
$status = "PASS"
function Fail([string]$Reason){ $script:status="FAIL"; $stop.Add($Reason) | Out-Null }

$inCI = ($env:GITHUB_ACTIONS -eq "true")
if(-not $inCI -and -not $AllowLocal){
  Fail "FAIL_NOT_CI_CONTEXT: GITHUB_ACTIONS not set"
}

$wf = Join-Path $RepoRoot ".github/workflows/scorecard.yml"
if(-not (Test-Path -LiteralPath $wf -PathType Leaf)){
  Fail "FAIL_MISSING_INPUT: missing .github/workflows/scorecard.yml"
}

if($status -eq "PASS"){
  $content = Get-Content -LiteralPath $wf -Raw
  if(-not ($content -match "ossf/scorecard-action@")){ Fail "FAIL_POLICY_VIOLATION: scorecard action step not found" }
  if(-not ($content -match "security-events:\s*write")){ Fail "FAIL_POLICY_VIOLATION: security-events: write permission missing" }
  if(-not ($content -match "id-token:\s*write")){ Fail "FAIL_POLICY_VIOLATION: id-token: write permission missing" }
}

$doc = [ordered]@{
  schema_version = 1
  kind = $gateId
  created_utc = $ts
  status = $status
  stop_reasons = @($stop)
  inputs = [ordered]@{ workflow = ".github/workflows/scorecard.yml" }
}

VF-WriteJson $p.outJson $doc 40
VF-WriteText $p.outTxt ("{0}`ncreated_utc={1}`nstatus={2}" -f $gateId,$ts,$status)

$outs = [ordered]@{
  txt = $p.outTxt
  json = $p.outJson
  txt_sha256 = (VF-Sha256 $p.outTxt)
  json_sha256 = (VF-Sha256 $p.outJson)
}
VF-EmitReceipt $p.outRcpt "receipt_gate" $status @{ repo_root=$RepoRoot; ci=$inCI } $outs

if($status -ne "PASS"){ exit 2 }
exit 0
