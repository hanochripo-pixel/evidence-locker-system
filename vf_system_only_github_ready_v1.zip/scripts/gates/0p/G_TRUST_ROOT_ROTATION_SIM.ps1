param(
  [Parameter(Mandatory=$true)][string]$RepoRoot
)

. (Join-Path $RepoRoot "scripts/lib/VF_LIB.ps1")

$gateId = "G_TRUST_ROOT_ROTATION_SIM"
$receiptId = "receipt_g_trust_root_rotation_sim"
$p = VF-NewGatePaths $RepoRoot $gateId $receiptId
$ts = VF-NowUtc

$stop = New-Object System.Collections.Generic.List[string]
$status = "PASS"
function Fail([string]$Reason){ $script:status="FAIL"; $stop.Add($Reason) | Out-Null }

$casesPath = Join-Path $RepoRoot "tests/root_rotation_sim/cases.json"
if(-not (Test-Path -LiteralPath $casesPath -PathType Leaf)){ Fail "FAIL_MISSING_INPUT: missing tests/root_rotation_sim/cases.json" }

$reportOut = Join-Path $RepoRoot "artifacts/trust/trust_rotation_sim.latest.json"
VF-EnsureDir (Split-Path -Parent $reportOut)

$cases = $null
if($status -eq "PASS"){
  try { $cases = Get-Content -LiteralPath $casesPath -Raw | ConvertFrom-Json } catch { Fail "FAIL_SCHEMA_INVALID: cases.json invalid json" }
}

$results = @()
if($status -eq "PASS"){
  foreach($c in @($cases.cases)){
    $caseId = $c.case_id
    $expected = $c.expected
    $b = $c.bundle
    $actual = "PASS"
    $reason = $null
    try {
      $issued = [DateTime]::Parse($b.bundle_issued_utc).ToUniversalTime()
      $expires = [DateTime]::Parse($b.bundle_expires_utc).ToUniversalTime()
      $maxStale = [int]$b.max_staleness_days
      $now = (Get-Date).ToUniversalTime()
      if($expires -lt $now){ $actual="FAIL"; $reason="FAIL_TRUST_BUNDLE_STALE: expired" }
      $staleDays = [Math]::Floor(($now - $issued).TotalDays)
      if($staleDays -gt $maxStale){ $actual="FAIL"; $reason="FAIL_TRUST_BUNDLE_STALE: stale" }
    } catch {
      $actual="FAIL"; $reason="FAIL_SCHEMA_INVALID: invalid bundle fields"
    }

    $ok = ($actual -eq $expected)
    if(-not $ok){
      Fail ("FAIL_POLICY_VIOLATION: rotation sim mismatch case={0} expected={1} actual={2}" -f $caseId,$expected,$actual)
    }

    $results += [ordered]@{ case_id=$caseId; expected=$expected; actual=$actual; ok=$ok; reason=$reason }
  }
}

$simReport = [ordered]@{
  schema_version = 1
  kind = "trust_rotation_sim"
  created_utc = $ts
  status = $status
  results = @($results)
}
VF-WriteJson $reportOut $simReport 60

$doc = [ordered]@{
  schema_version = 1
  kind = $gateId
  created_utc = $ts
  status = $status
  stop_reasons = @($stop)
  outputs = [ordered]@{
    trust_rotation_sim = $reportOut
    trust_rotation_sim_sha256 = (VF-Sha256 $reportOut)
  }
}

VF-WriteJson $p.outJson $doc 60

$txt = @()
$txt += $gateId
$txt += "created_utc=$ts"
$txt += "status=$status"
VF-WriteText $p.outTxt ($txt -join "`n")

$outs = [ordered]@{
  txt = $p.outTxt
  json = $p.outJson
  trust_rotation_sim = $reportOut
  trust_rotation_sim_sha256 = (VF-Sha256 $reportOut)
  txt_sha256 = (VF-Sha256 $p.outTxt)
  json_sha256 = (VF-Sha256 $p.outJson)
}
VF-EmitReceipt $p.outRcpt "receipt_gate" $status @{ repo_root=$RepoRoot; cases="tests/root_rotation_sim/cases.json" } $outs

if($status -ne "PASS"){ exit 2 }
exit 0
