param(
  [Parameter(Mandatory=$true)][string]$RepoRoot,
  [Parameter(Mandatory=$false)][int]$MaxMinutes = 15
)

. (Join-Path $RepoRoot "scripts/lib/VF_LIB.ps1")

$gateId = "G_TTFP_PROOF"
$receiptId = "receipt_g_ttfp_proof"
$p = VF-NewGatePaths $RepoRoot $gateId $receiptId
$ts = VF-NowUtc

$stop = New-Object System.Collections.Generic.List[string]
$status = "PASS"
function Fail([string]$Reason){ $script:status="FAIL"; $stop.Add($Reason) | Out-Null }

$proofPath = Join-Path $RepoRoot "artifacts/ttfp/ttfp_proof.latest.json"
if(-not (Test-Path -LiteralPath $proofPath -PathType Leaf)){
  Fail "FAIL_MISSING_INPUT: missing artifacts/ttfp/ttfp_proof.latest.json (run scripts/gates/RUN_0P_GATES.ps1)"
}

$mins = $null
if($status -eq "PASS"){
  try {
    $pobj = Get-Content -LiteralPath $proofPath -Raw | ConvertFrom-Json
    $mins = [double]$pobj.metrics.ttfp_minutes
    if($mins -gt $MaxMinutes){ Fail ("FAIL_TTFP_EXCEEDED: minutes={0} max={1}" -f $mins,$MaxMinutes) }
  } catch {
    Fail "FAIL_SCHEMA_INVALID: invalid ttfp proof json"
  }
}

$doc = [ordered]@{
  schema_version = 1
  kind = $gateId
  created_utc = $ts
  status = $status
  stop_reasons = @($stop)
  inputs = [ordered]@{ ttfp_proof = "artifacts/ttfp/ttfp_proof.latest.json" }
  metrics = [ordered]@{ ttfp_minutes = $mins; max_minutes = $MaxMinutes }
}

VF-WriteJson $p.outJson $doc 40
VF-WriteText $p.outTxt ("{0}`ncreated_utc={1}`nstatus={2}`nttfp_minutes={3}" -f $gateId,$ts,$status,$mins)

$outs = [ordered]@{
  txt = $p.outTxt
  json = $p.outJson
  txt_sha256 = (VF-Sha256 $p.outTxt)
  json_sha256 = (VF-Sha256 $p.outJson)
}
VF-EmitReceipt $p.outRcpt "receipt_gate" $status @{ repo_root=$RepoRoot; max_minutes=$MaxMinutes } $outs

if($status -ne "PASS"){ exit 2 }
exit 0
