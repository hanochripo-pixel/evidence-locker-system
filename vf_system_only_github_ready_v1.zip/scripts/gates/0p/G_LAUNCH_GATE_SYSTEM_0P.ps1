param(
  [Parameter(Mandatory=$true)][string]$RepoRoot
)

. (Join-Path $RepoRoot "scripts/lib/VF_LIB.ps1")

$gateId = "G_LAUNCH_GATE_SYSTEM_0P"
$receiptId = "receipt_g_launch_gate_system_0p"
$p = VF-NewGatePaths $RepoRoot $gateId $receiptId
$ts = VF-NowUtc

$stop = New-Object System.Collections.Generic.List[string]
$status = "PASS"
function Fail([string]$Reason){ $script:status="FAIL"; $stop.Add($Reason) | Out-Null }

# System meta gate: asserts that all required receipts exist and are PASS.

$requiredReceipts = @(
  "pre_00_runtime_contract.latest.json",
  "pre_00.latest.json",
  "receipt_verify_09a_policy_spec.latest.json",
  "vf_repo_snapshot_00.latest.json",
  "receipt_g_repo_health_files_assert.latest.json",
  "receipt_g_ci_hardening_assert.latest.json",
  "receipt_g_scorecard_assert.latest.json",
  "receipt_g_claim_ladder_lint.latest.json",
  "receipt_g_evidence_contract_validate.latest.json",
  "receipt_g_determinism_doe.latest.json",
  "receipt_g_sarif_validate.latest.json",
  "receipt_g_trust_root_rotation_sim.latest.json",
  "receipt_g_failpack_run_min.latest.json",
  "receipt_g_failpack_run_contract_min.latest.json",
  "receipt_g_ttfp_proof.latest.json"
)

$rcptDir = Join-Path $RepoRoot "receipts"
foreach($r in $requiredReceipts){
  $full = Join-Path $rcptDir $r
  if(-not (Test-Path -LiteralPath $full -PathType Leaf)){
    Fail ("FAIL_MISSING_RECEIPT: {0}" -f $r)
    continue
  }
  try{
    $obj = Get-Content -LiteralPath $full -Raw | ConvertFrom-Json -Depth 120
    if($obj.status -ne "PASS"){
      Fail ("FAIL_UPSTREAM_GATE: {0} status={1}" -f $r,$obj.status)
    }
  } catch {
    Fail ("FAIL_RECEIPT_UNREADABLE: {0}: {1}" -f $r,$_.Exception.Message)
  }
}

$outs = [ordered]@{
  required_receipts = $requiredReceipts
  required_count = $requiredReceipts.Count
}

VF-WriteJson $p.outJson [ordered]@{
  schema_version = 1
  kind = "gate_output"
  gate_id = $gateId
  created_utc = $ts
  status = $status
  failures = @($stop)
  outputs = $outs
} 40

VF-EmitReceipt $p.outRcpt "receipt_gate" $status @{ repo_root=$RepoRoot } $outs

if($status -ne "PASS"){ exit 2 }
exit 0
