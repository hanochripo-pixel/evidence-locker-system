param(
  [Parameter(Mandatory=$true)][string]$RepoRoot,
  [Parameter(Mandatory=$false)][string]$FailPackManifest = "samples/fixtures/failpack/failpack_manifest.json"
)

Set-StrictMode -Version Latest
$ErrorActionPreference="Stop"

. (Join-Path $RepoRoot "scripts/lib/VF_LIB.ps1")

$gateId = "G_FAILPACK_RUN_MIN"
$receiptId = "receipt_g_failpack_run_min"
$RepoRoot = (Resolve-Path -LiteralPath $RepoRoot).Path
$p = VF-NewGatePaths $RepoRoot $gateId $receiptId
$ts = VF-NowUtc

$stop = New-Object System.Collections.Generic.List[string]
$status = "PASS"
function Fail([string]$Reason){ $script:status="FAIL"; $stop.Add($Reason) | Out-Null }

$manifestPath = Join-Path $RepoRoot $FailPackManifest
$schemaPath = Join-Path $RepoRoot "schemas/failpack_manifest.schema.json"

if(-not (Test-Path -LiteralPath $manifestPath -PathType Leaf)){
  Fail ("FAIL_MISSING_INPUT: missing failpack manifest {0}" -f $FailPackManifest)
}

# Optional schema validation (best-effort; fail-closed on errors)
if($status -eq "PASS" -and (Test-Path -LiteralPath $schemaPath -PathType Leaf)){
  try {
    $jsonRaw = Get-Content -LiteralPath $manifestPath -Raw -ErrorAction Stop
    $ok = Test-Json -Json $jsonRaw -SchemaFile $schemaPath -ErrorAction Stop
    if(-not $ok){ Fail "FAIL_SCHEMA_INVALID: failpack manifest does not conform to schema" }
  } catch {
    Fail ("FAIL_SCHEMA_INVALID: failpack manifest/schema validation error: {0}" -f $_.Exception.Message)
  }
}

$fp = $null
if($status -eq "PASS"){
  try {
    $fp = Get-Content -LiteralPath $manifestPath -Raw -ErrorAction Stop | ConvertFrom-Json -ErrorAction Stop
  } catch {
    Fail ("FAIL_SCHEMA_INVALID: cannot parse failpack manifest json: {0}" -f $_.Exception.Message)
  }
}

# Resolve base pack (expected PASS)
$baseZip = $null
if($status -eq "PASS"){
  $baseZip = Join-Path $RepoRoot ($fp.base_pack.zip_path)
  if(-not (Test-Path -LiteralPath $baseZip -PathType Leaf)){
    Fail ("FAIL_MISSING_INPUT: base_pack zip missing: {0}" -f $fp.base_pack.zip_path)
  }
}

$verifyScript = Join-Path $RepoRoot "scripts/verify/VERIFY_08C_pack_offline_verify_strict.ps1"
if($status -eq "PASS" -and -not (Test-Path -LiteralPath $verifyScript -PathType Leaf)){
  Fail "FAIL_MISSING_INPUT: missing verifier script scripts/verify/VERIFY_08C_pack_offline_verify_strict.ps1"
}

$tmpRoot = Join-Path $RepoRoot "artifacts/_tmp_failpack"
VF-EnsureDir $tmpRoot

function Run-Verify([string]$Zip, [string]$OutDir){
  VF-EnsureDir $OutDir
  $cmd = @("pwsh","-NoProfile","-ExecutionPolicy","Bypass","-File",$verifyScript,"-ZipPath",$Zip,"-OutDir",$OutDir)
  $p = Start-Process -FilePath $cmd[0] -ArgumentList $cmd[1..($cmd.Count-1)] -NoNewWindow -PassThru -Wait
  $outJson = Join-Path $OutDir "logs/VERIFY_08C_pack_offline_verify_strict.latest.json"
  $doc = $null
  if(Test-Path -LiteralPath $outJson -PathType Leaf){
    try { $doc = Get-Content -LiteralPath $outJson -Raw | ConvertFrom-Json } catch { $doc = $null }
  }
  return [ordered]@{
    exit_code = $p.ExitCode
    out_json = $outJson
    doc = $doc
  }
}

# Baseline must PASS
$baseline = $null
if($status -eq "PASS"){
  $baseline = Run-Verify $baseZip (Join-Path $tmpRoot "baseline")
  if($baseline.exit_code -ne 0){
    Fail "FAIL_UNEXPECTED_FAIL: baseline base_pack did not PASS VERIFY_08C"
  }
}

# Required coverage targets must be represented by at least one OK case
$requiredTargets = @()
if($fp -and $fp.coverage_targets){
  $requiredTargets = @($fp.coverage_targets | Where-Object { $_.required -eq $true } | Select-Object -ExpandProperty target_id)
}

# Cases (expected FAIL)
$cases = @()
if($status -eq "PASS"){
  foreach($c in @($fp.cases)){
    $caseId = $c.case_id
    $covers = @()
    if($c.covers){ $covers = @($c.covers) }

    $zipRel = $c.materialize.mutated_zip_path
    if(-not $zipRel){
      Fail ("FAIL_SCHEMA_INVALID: case missing materialize.mutated_zip_path case_id={0}" -f $caseId)
      continue
    }
    $zipFull = Join-Path $RepoRoot $zipRel
    $run = Run-Verify $zipFull (Join-Path $tmpRoot $caseId)

    $expExit = [int]$c.expected.expected_exit_code
    $expOutcome = $c.expected.outcome.ToString()
    $actOutcome = if($run.exit_code -eq 0){ "PASS" } else { "FAIL" }

    $obsCodes = @()
    if($run.doc -and $run.doc.reason_codes){
      $obsCodes = @($run.doc.reason_codes)
    }

    $expAny = @($c.expected.expected_reason_codes_any)
    $expAll = @()
    if($c.expected.expected_reason_codes_all){ $expAll = @($c.expected.expected_reason_codes_all) }

    $ok = $true
    $notes = New-Object System.Collections.Generic.List[string]

    if($run.exit_code -ne $expExit){
      $ok = $false
      $notes.Add(("exit_code mismatch expected={0} actual={1}" -f $expExit,$run.exit_code)) | Out-Null
      if($expOutcome -eq "FAIL" -and $actOutcome -eq "PASS"){
        Fail ("FAIL_UNEXPECTED_PASS: case passed but expected FAIL case_id={0} zip={1}" -f $caseId,$zipRel)
      } else {
        Fail ("FAIL_UNEXPECTED_FAIL: case did not match expected exit code case_id={0}" -f $caseId)
      }
    }

    if($expOutcome -ne $actOutcome){
      $ok = $false
      $notes.Add(("outcome mismatch expected={0} actual={1}" -f $expOutcome,$actOutcome)) | Out-Null
    }

    # Reason code checks (any-of required for FAIL)
    if($expOutcome -eq "FAIL"){
      $hitAny = $false
      foreach($e in $expAny){
        if($obsCodes -contains $e){ $hitAny = $true; break }
      }
      if(-not $hitAny){
        $ok = $false
        $notes.Add(("reason_codes_any mismatch expected_any={0} observed={1}" -f ($expAny -join ","), ($obsCodes -join ","))) | Out-Null
        Fail ("FAIL_POLICY_VIOLATION: reason_codes_any not satisfied case_id={0}" -f $caseId)
      }

      if($expAll.Count -gt 0){
        foreach($e in $expAll){
          if(-not ($obsCodes -contains $e)){
            $ok = $false
            $notes.Add(("reason_codes_all missing={0}" -f $e)) | Out-Null
            Fail ("FAIL_POLICY_VIOLATION: reason_codes_all not satisfied case_id={0}" -f $caseId)
          }
        }
      }
    }

    $cases += [ordered]@{
      case_id = $caseId
      title = $c.title
      covers = @($covers)
      mutated_zip = $zipRel
      expected = [ordered]@{
        outcome = $expOutcome
        exit_code = $expExit
        reason_codes_any = @($expAny)
        reason_codes_all = @($expAll)
      }
      actual = [ordered]@{
        outcome = $actOutcome
        exit_code = $run.exit_code
        reason_codes = @($obsCodes)
        verify_log = $run.out_json.Substring($RepoRoot.Length).TrimStart('\','/')
      }
      ok = $ok
      notes = @($notes)
    }
  }
}

# Coverage metrics
$total = ($cases | Measure-Object).Count
$okCount = ($cases | Where-Object { $_.ok -eq $true } | Measure-Object).Count
$coverage = 0.0
if($total -gt 0){ $coverage = [Math]::Round(($okCount / $total), 4) }

# Coverage target enforcement: each required target_id must have at least one OK case claiming it
$targetsOk = @()
foreach($t in $requiredTargets){
  $hit = ($cases | Where-Object { $_.ok -eq $true -and ($_.covers -contains $t) } | Measure-Object).Count
  if($hit -gt 0){ $targetsOk += $t }
}
$targetsMissing = @($requiredTargets | Where-Object { $targetsOk -notcontains $_ })
if($targetsMissing.Count -gt 0){
  Fail ("FAIL_POLICY_VIOLATION: required coverage_targets not satisfied: {0}" -f ($targetsMissing -join ","))
}

$reportOut = Join-Path $RepoRoot "artifacts/failpack/failpack_report.latest.json"
VF-EnsureDir (Split-Path -Parent $reportOut)

$rep = [ordered]@{
  schema_version = 1
  kind = "failpack_report"
  created_utc = $ts
  status = $status
  baseline = [ordered]@{
    zip = ($fp.base_pack.zip_path)
    exit_code = if($baseline){ $baseline.exit_code } else { $null }
  }
  cases = @($cases)
  metrics = [ordered]@{
    cases_total = $total
    cases_ok = $okCount
    coverage = $coverage
    coverage_targets_required = ($requiredTargets | Measure-Object).Count
    coverage_targets_ok = ($targetsOk | Measure-Object).Count
    coverage_targets_missing = @($targetsMissing)
  }
}
VF-WriteJson $reportOut $rep 140

$doc = [ordered]@{
  schema_version = 1
  kind = $gateId
  created_utc = $ts
  status = $status
  stop_reasons = @($stop)
  outputs = [ordered]@{
    failpack_report = $reportOut
    failpack_report_sha256 = (VF-Sha256 $reportOut)
  }
  metrics = $rep.metrics
}
VF-WriteJson $p.outJson $doc 160
VF-WriteText $p.outTxt ("{0}`ncreated_utc={1}`nstatus={2}`ncoverage={3}`ncases_total={4}`ncases_ok={5}`ncoverage_targets_ok={6}/{7}" -f $gateId,$ts,$status,$coverage,$total,$okCount,$rep.metrics.coverage_targets_ok,$rep.metrics.coverage_targets_required)

$outs = [ordered]@{
  txt = $p.outTxt
  json = $p.outJson
  failpack_report = $reportOut
  failpack_report_sha256 = (VF-Sha256 $reportOut)
  txt_sha256 = (VF-Sha256 $p.outTxt)
  json_sha256 = (VF-Sha256 $p.outJson)
}
VF-EmitReceipt $p.outRcpt "receipt_gate" $status @{ repo_root=$RepoRoot; failpack_manifest=$FailPackManifest } $outs

if($status -ne "PASS"){ exit 2 }
exit 0
