param(
  [Parameter(Mandatory=$true)][string]$RepoRoot
)

. (Join-Path $RepoRoot "scripts/lib/VF_LIB.ps1")
. (Join-Path $RepoRoot "scripts/lib/VF_CONTRACTS.ps1")

$gateId = "G_SARIF_VALIDATE"
$receiptId = "receipt_g_sarif_validate"
$p = VF-NewGatePaths $RepoRoot $gateId $receiptId
$ts = VF-NowUtc

$stop = New-Object System.Collections.Generic.List[string]
$status = "PASS"
function Fail([string]$Reason){ $script:status="FAIL"; $stop.Add($Reason) | Out-Null }

$fixture = Join-Path $RepoRoot "samples/fixtures/pass_packet_min.zip"
if(-not (Test-Path -LiteralPath $fixture -PathType Leaf)){ Fail "FAIL_MISSING_INPUT: missing samples/fixtures/pass_packet_min.zip" }

if($status -eq "PASS"){
  # Extract SARIF from fixture
  $tmp = Join-Path $RepoRoot "artifacts/_tmp_sarif"
  VF-EnsureDir $tmp
  $work = Join-Path $tmp ([IO.Path]::GetRandomFileName())
  VF-EnsureDir $work
    try {
      VF-SafeExpandArchive -ZipPath $fixture -DestinationPath $work -Force
    } catch {
      Fail ("FAIL_POLICY_VIOLATION: unsafe_zip_expand: {0}" -f $_.Exception.Message)
    }
  $sarifPath = Join-Path $work "sarif/results.sarif"
  if(-not (Test-Path -LiteralPath $sarifPath -PathType Leaf)){ Fail "FAIL_MISSING_INPUT: sarif/results.sarif missing in fixture" }
  else {
    try {
      $s = Get-Content -LiteralPath $sarifPath -Raw | ConvertFrom-Json
      if(-not $s.version){ Fail "FAIL_POLICY_VIOLATION: missing sarif.version" }
      if(-not $s.runs -or $s.runs.Count -lt 1){ Fail "FAIL_POLICY_VIOLATION: missing sarif.runs" }
      if(-not $s.runs[0].tool.driver.name){ Fail "FAIL_POLICY_VIOLATION: missing tool.driver.name" }
      if(-not $s.runs[0].PSObject.Properties.Name -contains "results"){ Fail "FAIL_POLICY_VIOLATION: missing runs[0].results" }
    } catch {
      Fail "FAIL_SCHEMA_INVALID: sarif invalid json"
    }
  }
}

$doc = [ordered]@{
  schema_version = 1
  kind = $gateId
  created_utc = $ts
  status = $status
  stop_reasons = @($stop)
}

VF-WriteJson $p.outJson $doc 40
VF-WriteText $p.outTxt ("{0}`ncreated_utc={1}`nstatus={2}" -f $gateId,$ts,$status)

$outs = [ordered]@{
  txt = $p.outTxt
  json = $p.outJson
  txt_sha256 = (VF-Sha256 $p.outTxt)
  json_sha256 = (VF-Sha256 $p.outJson)
}
VF-EmitReceipt $p.outRcpt "receipt_gate" $status @{ repo_root=$RepoRoot } $outs

if($status -ne "PASS"){ exit 2 }
exit 0
