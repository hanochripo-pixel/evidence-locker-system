param(
  [Parameter(Mandatory=$true)][string]$RepoRoot
)

. (Join-Path $RepoRoot "scripts/lib/VF_LIB.ps1")

$gateId = "G_CLAIM_LADDER_LINT"
$receiptId = "receipt_g_claim_ladder_lint"
$p = VF-NewGatePaths $RepoRoot $gateId $receiptId
$ts = VF-NowUtc

$requiredDocs = @("docs/claim_red_flags.md","docs/standards_language.md")
$stop = New-Object System.Collections.Generic.List[string]
$status = "PASS"
function Fail([string]$Reason){ $script:status="FAIL"; $stop.Add($Reason) | Out-Null }

foreach($d in $requiredDocs){
  $full = Join-Path $RepoRoot $d
  if(-not (Test-Path -LiteralPath $full -PathType Leaf)){
    Fail ("FAIL_MISSING_INPUT: missing {0}" -f $d)
  }
}

$forbidden = @(
  "the only",
  "world's only",
  "compliant",
  "certified",
  "implements "
)

$hits = @()
$scanRoots = @()
$readme = Join-Path $RepoRoot "README.md"
if(Test-Path -LiteralPath $readme -PathType Leaf){ $scanRoots += $readme }
$docsDir = Join-Path $RepoRoot "docs"
if(Test-Path -LiteralPath $docsDir -PathType Container){
  $scanRoots += (Get-ChildItem -LiteralPath $docsDir -Recurse -File -Filter "*.md" | Select-Object -ExpandProperty FullName)
}

if($status -eq "PASS"){
  foreach($f in $scanRoots){
    $lines = Get-Content -LiteralPath $f -ErrorAction SilentlyContinue
    for($i=0; $i -lt $lines.Count; $i++){
      $line = $lines[$i]
      foreach($phrase in $forbidden){
        if($line -match [regex]::Escape($phrase)){
          $hits += [ordered]@{
            file = $f.Substring($RepoRoot.Length).TrimStart("\","/") -replace "\\","/"
            line = ($i+1)
            phrase = $phrase
            excerpt = $line.Trim()
          }
        }
      }
    }
  }
  if($hits.Count -gt 0){
    foreach($h in $hits){
      Fail ("FAIL_FORBIDDEN_CLAIM: {0}:{1} phrase='{2}'" -f $h.file,$h.line,$h.phrase)
    }
  }
}

$doc = [ordered]@{
  schema_version = 1
  kind = $gateId
  created_utc = $ts
  status = $status
  stop_reasons = @($stop)
  hits = @($hits)
  metrics = [ordered]@{
    forbidden_hits_count = $hits.Count
  }
}

VF-WriteJson $p.outJson $doc 60

$txt = @()
$txt += $gateId
$txt += "created_utc=$ts"
$txt += "status=$status"
$txt += ("forbidden_hits_count={0}" -f $hits.Count)
if($hits.Count -gt 0){
  $txt += ""
  $txt += "hits:"
  foreach($h in $hits){
    $txt += ("  - {0}:{1} phrase='{2}'" -f $h.file,$h.line,$h.phrase)
  }
}
VF-WriteText $p.outTxt ($txt -join "`n")

$outs = [ordered]@{
  txt = $p.outTxt
  json = $p.outJson
  txt_sha256 = (VF-Sha256 $p.outTxt)
  json_sha256 = (VF-Sha256 $p.outJson)
}
VF-EmitReceipt $p.outRcpt "receipt_gate" $status @{ repo_root=$RepoRoot } $outs

if($status -ne "PASS"){ exit 2 }
exit 0
