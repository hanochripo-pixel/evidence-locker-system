param(
  [Parameter(Mandatory=$true)][string]$RepoRoot
)

. (Join-Path $RepoRoot "scripts/lib/VF_LIB.ps1")
. (Join-Path $RepoRoot "scripts/lib/VF_CONTRACTS.ps1")

$gateId = "G_EVIDENCE_CONTRACT_VALIDATE"
$receiptId = "receipt_g_evidence_contract_validate"
$p = VF-NewGatePaths $RepoRoot $gateId $receiptId
$ts = VF-NowUtc

$stop = New-Object System.Collections.Generic.List[string]
$status = "PASS"
function Fail([string]$Reason){ $script:status="FAIL"; $stop.Add($Reason) | Out-Null }

# Required files
$required = @(
  "docs/evidence_contract.md",
  "schemas/evidence_packet.schema.json",
  "schemas/decision_record.schema.json",
  "schemas/metrics_report.schema.json",
  "schemas/failpack_manifest.schema.json",
  "schemas/trust_root_bundle.schema.json",
  "samples/fixtures/pass_packet_min.zip"
)

foreach($r in $required){
  $full = Join-Path $RepoRoot $r
  if(-not (Test-Path -LiteralPath $full)){
    Fail ("FAIL_MISSING_INPUT: missing {0}" -f $r)
  }
}

# Parse schemas as JSON (structure sanity)
foreach($s in @(
  "schemas/evidence_packet.schema.json",
  "schemas/decision_record.schema.json",
  "schemas/metrics_report.schema.json",
  "schemas/failpack_manifest.schema.json",
  "schemas/trust_root_bundle.schema.json"
)){
  $full = Join-Path $RepoRoot $s
  if(Test-Path -LiteralPath $full){
    try { Get-Content -LiteralPath $full -Raw | ConvertFrom-Json | Out-Null } catch { Fail ("FAIL_SCHEMA_INVALID: invalid schema json: {0}" -f $s) }
  }
}

# Validate fixture packet
$fixture = Join-Path $RepoRoot "samples/fixtures/pass_packet_min.zip"
$val = VF-ValidateEvidencePacketZip $fixture (Join-Path $RepoRoot "artifacts/_tmp_validate")
if($val.status -ne "PASS"){
  $status = "FAIL"
  foreach($r in @($val.reasons)){ $stop.Add($r) | Out-Null }
}

$doc = [ordered]@{
  schema_version = 1
  kind = $gateId
  created_utc = $ts
  status = $status
  stop_reasons = @($stop)
  metrics = [ordered]@{
    required_items_count = $required.Count
    schema_parse_ok = ($stop | Where-Object { $_ -match "FAIL_SCHEMA_INVALID" } | Measure-Object).Count -eq 0
  }
}

VF-WriteJson $p.outJson $doc 60

$txt = @()
$txt += $gateId
$txt += "created_utc=$ts"
$txt += "status=$status"
if($stop.Count -gt 0){
  $txt += ""
  $txt += "stop_reasons:"
  foreach($r in @($stop)){ $txt += ("  - " + $r) }
}
VF-WriteText $p.outTxt ($txt -join "`n")

$outs = [ordered]@{
  txt = $p.outTxt
  json = $p.outJson
  txt_sha256 = (VF-Sha256 $p.outTxt)
  json_sha256 = (VF-Sha256 $p.outJson)
}
VF-EmitReceipt $p.outRcpt "receipt_gate" $status @{ repo_root=$RepoRoot; fixture="samples/fixtures/pass_packet_min.zip" } $outs

if($status -ne "PASS"){ exit 2 }
exit 0
