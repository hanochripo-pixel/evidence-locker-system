param(
  [Parameter(Mandatory=$true)][string]$RepoRoot,
  [Parameter(Mandatory=$false)][switch]$AllowLocal
)

. (Join-Path $RepoRoot "scripts/lib/VF_LIB.ps1")

$gateId = "G_CI_HARDENING_ASSERT"
$receiptId = "receipt_g_ci_hardening_assert"
$p = VF-NewGatePaths $RepoRoot $gateId $receiptId
$ts = VF-NowUtc

$stop = New-Object System.Collections.Generic.List[string]
$status = "PASS"
function Fail([string]$Reason){ $script:status="FAIL"; $stop.Add($Reason) | Out-Null }

$inCI = ($env:GITHUB_ACTIONS -eq "true")
if(-not $inCI -and -not $AllowLocal){
  Fail "FAIL_NOT_CI_CONTEXT: GITHUB_ACTIONS not set"
}

$wfDir = Join-Path $RepoRoot ".github/workflows"
if(-not (Test-Path -LiteralPath $wfDir -PathType Container)){
  Fail "FAIL_MISSING_INPUT: missing .github/workflows/"
}

$totalUses = 0
$pinnedUses = 0
$danger = 0
$notes = @()
$workflows = @()

function Is-Pinned-UsesRef([string]$ref){
  if([string]::IsNullOrWhiteSpace($ref)){ return $false }

  # Local action in-repo
  if($ref -match "^(\./|\.\\)"){ return $true }

  # Docker digest pin (strongest form for docker://)
  if($ref -match "^docker://.+@sha256:[0-9a-f]{64}$"){ return $true }

  # Git ref pinned to full commit SHA
  if($ref -match "@[0-9a-f]{40}$"){ return $true }

  return $false
}

if($status -eq "PASS"){
  $files = Get-ChildItem -LiteralPath $wfDir -File -Recurse -Include *.yml,*.yaml
  if(-not $files -or $files.Count -eq 0){
    Fail "FAIL_MISSING_INPUT: no workflow files found under .github/workflows/"
  } else {
    foreach($f in $files){
      $rel = (Resolve-Path -LiteralPath $f.FullName).Path.Substring($RepoRoot.Length).TrimStart("\","/").Replace("\","/")
      $workflows += $rel

      $content = Get-Content -LiteralPath $f.FullName -Raw

      # Top-level permissions MUST exist (either scalar or mapping). We enforce presence.
      if(-not ($content -match "(?m)^permissions:\s*")) {
        Fail ("FAIL_POLICY_VIOLATION: workflow missing top-level permissions block: {0}" -f $rel)
      }

      # count uses:
      $matches = [regex]::Matches($content, "(?m)^\s*uses:\s*([^\s#]+)")
      foreach($m in $matches){
        $totalUses++
        $ref = $m.Groups[1].Value.Trim()
        if(Is-Pinned-UsesRef $ref){ $pinnedUses++ }
        else { Fail ("FAIL_TOOLCHAIN_UNPINNED: {0} in {1}" -f $ref,$rel) }
      }

      if($content -match "pull_request_target"){ $danger++; Fail ("FAIL_DANGEROUS_WORKFLOW: pull_request_target present in {0}" -f $rel) }
      if($content -match "curl\s+https?://"){ $danger++; Fail ("FAIL_DANGEROUS_WORKFLOW: curl download detected in {0}" -f $rel) }
      if($content -match "Invoke-WebRequest\s+https?://"){ $danger++; Fail ("FAIL_DANGEROUS_WORKFLOW: Invoke-WebRequest download detected in {0}" -f $rel) }
    }
  }
}

$pinnedRatio = 0.0
if($totalUses -gt 0){ $pinnedRatio = [Math]::Round(($pinnedUses / $totalUses), 4) }

$doc = [ordered]@{
  schema_version = 1
  kind = $gateId
  created_utc = $ts
  status = $status
  stop_reasons = @($stop)
  metrics = [ordered]@{
    workflows_scanned = $workflows.Count
    total_uses = $totalUses
    pinned_uses = $pinnedUses
    pinned_actions_ratio = $pinnedRatio
    dangerous_patterns_count = $danger
  }
  inputs = [ordered]@{
    workflows_dir = ".github/workflows/"
    workflows = $workflows
  }
}

VF-WriteJson $p.outJson $doc 60

$txt = @()
$txt += $gateId
$txt += "created_utc=$ts"
$txt += "status=$status"
$txt += ("workflows_scanned={0}" -f $workflows.Count)
$txt += ("pinned_actions_ratio={0}" -f $pinnedRatio)
$txt += ("dangerous_patterns_count={0}" -f $danger)
VF-WriteText $p.outTxt ($txt -join "`n")

$outs = [ordered]@{
  txt = $p.outTxt
  json = $p.outJson
  txt_sha256 = (VF-Sha256 $p.outTxt)
  json_sha256 = (VF-Sha256 $p.outJson)
}
VF-EmitReceipt $p.outRcpt "receipt_gate" $status @{ repo_root=$RepoRoot; ci=$inCI } $outs

if($status -ne "PASS"){ exit 2 }
exit 0
