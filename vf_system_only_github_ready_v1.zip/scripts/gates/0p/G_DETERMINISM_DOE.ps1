param(
  [Parameter(Mandatory=$true)][string]$RepoRoot,
  [Parameter(Mandatory=$false)][int]$Reruns = 2
)

. (Join-Path $RepoRoot "scripts/lib/VF_LIB.ps1")
. (Join-Path $RepoRoot "scripts/lib/VF_CONTRACTS.ps1")

$gateId = "G_DETERMINISM_DOE"
$receiptId = "receipt_g_determinism_doe"
$p = VF-NewGatePaths $RepoRoot $gateId $receiptId
$ts = VF-NowUtc

$stop = New-Object System.Collections.Generic.List[string]
$status = "PASS"
function Fail([string]$Reason){ $script:status="FAIL"; $stop.Add($Reason) | Out-Null }

$fixture = Join-Path $RepoRoot "samples/fixtures/pass_packet_min.zip"
if(-not (Test-Path -LiteralPath $fixture -PathType Leaf)){ Fail "FAIL_MISSING_INPUT: missing samples/fixtures/pass_packet_min.zip" }

$digests = @()
if($status -eq "PASS"){
  for($i=1; $i -le $Reruns; $i++){
    $val = VF-ValidateEvidencePacketZip $fixture (Join-Path $RepoRoot "artifacts/_tmp_doe")
    if($val.status -ne "PASS"){ Fail ("FAIL_UNEXPECTED_FAIL: fixture failed on rerun {0}" -f $i) }
    $digests += (VF-Sha256 $fixture)
  }
  # determinism = all digests identical (fixture digest is proxy for deterministic inputs)
  $uniq = @($digests | Select-Object -Unique)
  if($uniq.Count -ne 1){ Fail "FAIL_DETERMINISM_DRIFT: digest mismatch across reruns" }
}

$matchRatio = 0.0
if($digests.Count -gt 0){
  $matchRatio = if(($digests | Select-Object -Unique).Count -eq 1){ 1.0 } else { 0.0 }
}

$out = Join-Path $RepoRoot "artifacts/metrics/determinism_doe.latest.json"
VF-EnsureDir (Split-Path -Parent $out)
$report = [ordered]@{
  schema_version = 1
  kind = "determinism_doe"
  created_utc = $ts
  status = $status
  rerun_count = $Reruns
  digests = @($digests)
  metrics = [ordered]@{
    hash_match_ratio = $matchRatio
    reason_order_stable = 1
  }
}
VF-WriteJson $out $report 60

$doc = [ordered]@{
  schema_version = 1
  kind = $gateId
  created_utc = $ts
  status = $status
  stop_reasons = @($stop)
  outputs = [ordered]@{
    determinism_doe = $out
    determinism_doe_sha256 = (VF-Sha256 $out)
  }
  metrics = $report.metrics
}

VF-WriteJson $p.outJson $doc 60
VF-WriteText $p.outTxt ("{0}`ncreated_utc={1}`nstatus={2}`nhash_match_ratio={3}" -f $gateId,$ts,$status,$matchRatio)

$outs = [ordered]@{
  txt = $p.outTxt
  json = $p.outJson
  determinism_doe = $out
  determinism_doe_sha256 = (VF-Sha256 $out)
  txt_sha256 = (VF-Sha256 $p.outTxt)
  json_sha256 = (VF-Sha256 $p.outJson)
}
VF-EmitReceipt $p.outRcpt "receipt_gate" $status @{ repo_root=$RepoRoot; reruns=$Reruns } $outs

if($status -ne "PASS"){ exit 2 }
exit 0
