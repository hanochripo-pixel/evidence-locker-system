param(
  [Parameter(Mandatory=$false)][string]$RepoRoot = "."
)

$ErrorActionPreference = "Stop"
Set-StrictMode -Version Latest

$RepoRoot = (Resolve-Path -LiteralPath $RepoRoot).Path
. (Join-Path $RepoRoot "scripts/lib/VF_LIB.ps1")

$start = Get-Date
$ts = VF-NowUtc

function Run-Gate([string]$RelScript, [string]$GateId) {
  $full = Join-Path $RepoRoot $RelScript
  if(-not (Test-Path -LiteralPath $full -PathType Leaf)){
    Write-Host ("FAIL: missing gate script {0}" -f $RelScript)
    exit 2
  }
  Write-Host ("== RUN: {0}" -f $GateId)
  pwsh -NoProfile -ExecutionPolicy Bypass -File $full -RepoRoot $RepoRoot
  if($LASTEXITCODE -ne 0){
    Write-Host ("FAIL: gate failed: {0} exit={1}" -f $GateId,$LASTEXITCODE)
    exit 2
  }
  Write-Host ("PASS: {0}" -f $GateId)
}

# System runner: IC + RC enforcement, excludes Paper-Core gates.

Run-Gate "scripts/preflight/PRE_00_RUNTIME_CONTRACT.ps1" "PRE_00_RUNTIME_CONTRACT"
Run-Gate "scripts/preflight/PRE_00.ps1" "PRE_00"
Run-Gate "scripts/verify/VERIFY_09A_policy_spec.ps1" "VERIFY_09A_POLICY_SPEC"
Run-Gate "scripts/snapshot/VF_REPO_SNAPSHOT_00.ps1" "VF_REPO_SNAPSHOT_00"

Run-Gate "scripts/gates/0p/G_REPO_HEALTH_FILES_ASSERT.ps1" "G_REPO_HEALTH_FILES_ASSERT"
Run-Gate "scripts/gates/0p/G_CLAIM_LADDER_LINT.ps1" "G_CLAIM_LADDER_LINT"

# CI-only gates: allow local execution for developer convenience (fail in CI if broken)
pwsh -NoProfile -ExecutionPolicy Bypass -File (Join-Path $RepoRoot "scripts/gates/0p/G_CI_HARDENING_ASSERT.ps1") -RepoRoot $RepoRoot -AllowLocal
  if($LASTEXITCODE -ne 0){ Write-Host "FAIL: gate failed: G_CI_HARDENING_ASSERT"; exit 2 }
  Write-Host "PASS: G_CI_HARDENING_ASSERT"
pwsh -NoProfile -ExecutionPolicy Bypass -File (Join-Path $RepoRoot "scripts/gates/0p/G_SCORECARD_ASSERT.ps1") -RepoRoot $RepoRoot -AllowLocal
  if($LASTEXITCODE -ne 0){ Write-Host "FAIL: gate failed: G_SCORECARD_ASSERT"; exit 2 }
  Write-Host "PASS: G_SCORECARD_ASSERT"

Run-Gate "scripts/gates/0p/G_EVIDENCE_CONTRACT_VALIDATE.ps1" "G_EVIDENCE_CONTRACT_VALIDATE"
Run-Gate "scripts/gates/0p/G_SARIF_VALIDATE.ps1" "G_SARIF_VALIDATE"
Run-Gate "scripts/gates/0p/G_TRUST_ROOT_ROTATION_SIM.ps1" "G_TRUST_ROOT_ROTATION_SIM"
Run-Gate "scripts/gates/0p/G_DETERMINISM_DOE.ps1" "G_DETERMINISM_DOE"
Run-Gate "scripts/gates/0p/G_FAILPACK_RUN_MIN.ps1" "G_FAILPACK_RUN_MIN"
Run-Gate "scripts/gates/0p/G_FAILPACK_RUN_CONTRACT_MIN.ps1" "G_FAILPACK_RUN_CONTRACT_MIN"

# Emit TTFP proof (measures this run)
$end = Get-Date
$mins = [Math]::Round(($end - $start).TotalMinutes, 3)
$proofDir = Join-Path $RepoRoot "artifacts/ttfp"
VF-EnsureDir $proofDir
$proofPath = Join-Path $proofDir "ttfp_proof.latest.json"

$proof = [ordered]@{
  schema_version = 1
  kind = "ttfp_proof"
  created_utc = $ts
  status = "PASS"
  metrics = [ordered]@{ ttfp_minutes = $mins }
}
VF-WriteJson $proofPath $proof 40

Run-Gate "scripts/gates/0p/G_TTFP_PROOF.ps1" "G_TTFP_PROOF"

# Repo-Core meta gate
Run-Gate "scripts/gates/0p/G_LAUNCH_GATE_SYSTEM_0P.ps1" "G_LAUNCH_GATE_SYSTEM_0P"

Write-Host ("PASS: RUN_0P_GATES_SYSTEM completed. ttfp_minutes={0}" -f $mins)
exit 0
