param(
  [Parameter(Mandatory=$false)][string]$RepoRoot = "."
)

# Default entry point: SYSTEM-ONLY 0P gates
pwsh -NoProfile -ExecutionPolicy Bypass -File (Join-Path $RepoRoot "scripts/gates/RUN_0P_GATES_SYSTEM.ps1") -RepoRoot $RepoRoot
exit $LASTEXITCODE
