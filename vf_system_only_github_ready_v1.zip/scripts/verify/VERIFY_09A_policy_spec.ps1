param(
  [Parameter(Mandatory=$true)][string]$RepoRoot
)

. (Join-Path $RepoRoot "scripts/lib/VF_LIB.ps1")

$gateId = "VERIFY_09A_POLICY_SPEC"
$receiptId = "receipt_verify_09a_policy_spec"
$p = VF-NewGatePaths $RepoRoot $gateId $receiptId
$ts = VF-NowUtc

$policyRel = "contracts/policy_spec.md"
$indexRel  = "contracts/policy_spec.index.json"

$policyPath = Join-Path $RepoRoot $policyRel
$indexPath  = Join-Path $RepoRoot $indexRel

$status = "PASS"
$stop = @()

$policyExists = (Test-Path -LiteralPath $policyPath -PathType Leaf)
$indexExists  = (Test-Path -LiteralPath $indexPath -PathType Leaf)

if(-not $policyExists){
  $status = "FAIL"
  $stop += ("FAIL_MISSING_INPUT: missing {0}" -f $policyRel)
}
if(-not $indexExists){
  $status = "FAIL"
  $stop += ("FAIL_MISSING_INPUT: missing {0}" -f $indexRel)
}

$metrics = [ordered]@{
  policy_exists = $policyExists
  index_exists = $indexExists
}

$missingHeaders = @()
$missingIds = @()
$duplicateIds = @()

if($status -eq "PASS"){
  $idxRaw = Get-Content -LiteralPath $indexPath -Raw
  $idx = $idxRaw | ConvertFrom-Json

  $policyText = Get-Content -LiteralPath $policyPath -Raw
  $policySize = (Get-Item -LiteralPath $policyPath).Length
  $minSize = [int]$idx.min_size_bytes

  $metrics.policy_size_bytes = $policySize
  $metrics.min_size_bytes = $minSize

  if($policySize -lt $minSize){
    $status = "FAIL"
    $stop += ("FAIL_POLICY_TOO_SMALL: size_bytes={0} min_size_bytes={1}" -f $policySize,$minSize)
  }

  foreach($h in $idx.required_headers){
    if(-not ($policyText -like ("*" + $h + "*"))){
      $missingHeaders += $h
    }
  }

  foreach($id in $idx.required_ids){
    $pat = "(?m)^\s*" + [regex]::Escape([string]$id) + ":"
    $m = [regex]::Matches($policyText, $pat)
    if($m.Count -eq 0){
      $missingIds += $id
    } elseif($m.Count -gt 1){
      $duplicateIds += $id
    }
  }

  if($missingHeaders.Count -gt 0){
    $status = "FAIL"
    foreach($h in $missingHeaders){
      $stop += ("FAIL_MISSING_HEADER: {0}" -f $h)
    }
  }
  if($missingIds.Count -gt 0){
    $status = "FAIL"
    foreach($id in $missingIds){
      $stop += ("FAIL_MISSING_CONTRACT_ID: {0}" -f $id)
    }
  }
  if($duplicateIds.Count -gt 0){
    $status = "FAIL"
    foreach($id in $duplicateIds){
      $stop += ("FAIL_DUPLICATE_CONTRACT_ID: {0}" -f $id)
    }
  }

  $metrics.missing_headers_count = $missingHeaders.Count
  $metrics.missing_ids_count = $missingIds.Count
  $metrics.duplicate_ids_count = $duplicateIds.Count

  $metrics.policy_sha256 = (VF-Sha256 $policyPath)
  $metrics.index_sha256 = (VF-Sha256 $indexPath)
}

$doc = [ordered]@{
  schema_version = 1
  kind = $gateId
  created_utc = $ts
  status = $status
  stop_reasons = @($stop)
  metrics = $metrics
}

VF-WriteJson $p.outJson $doc 50

$txt = @()
$txt += $gateId
$txt += ("created_utc={0}" -f $ts)
$txt += ("status={0}" -f $status)
$txt += ("policy_relpath={0}" -f $policyRel)
$txt += ("index_relpath={0}" -f $indexRel)
if($missingHeaders.Count -gt 0){
  $txt += ""
  $txt += "missing_headers:"
  foreach($h in $missingHeaders){ $txt += ("  - " + $h) }
}
if($missingIds.Count -gt 0){
  $txt += ""
  $txt += "missing_contract_ids:"
  foreach($id in $missingIds){ $txt += ("  - " + $id) }
}
if($duplicateIds.Count -gt 0){
  $txt += ""
  $txt += "duplicate_contract_ids:"
  foreach($id in $duplicateIds){ $txt += ("  - " + $id) }
}
VF-WriteText $p.outTxt ($txt -join "`n")

$outs = [ordered]@{
  txt = $p.outTxt
  json = $p.outJson
  txt_sha256 = (VF-Sha256 $p.outTxt)
  json_sha256 = (VF-Sha256 $p.outJson)
}

VF-EmitReceipt $p.outRcpt "receipt_gate" $status @{ repo_root=$RepoRoot } $outs

if($status -ne "PASS"){ exit 2 }
exit 0
