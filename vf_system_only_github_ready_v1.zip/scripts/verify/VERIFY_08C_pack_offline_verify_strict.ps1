param(
  [Parameter(Mandatory=$true)][string]$ZipPath,
  [Parameter(Mandatory=$false)][string]$OutDir = "."
)
Set-StrictMode -Version Latest
$ErrorActionPreference="Stop"

. (Join-Path $PSScriptRoot "..\lib\VF_LIB.ps1")

$gateId = "VERIFY_08C_pack_offline_verify_strict"
$receiptId = "verify_08C_pack_offline_verify_strict"

# Output root (default: current directory). Writes under <OutDir>/logs and <OutDir>/receipts
VF-EnsureDir $OutDir
$OutDir = (Resolve-Path -LiteralPath $OutDir).Path
$p = VF-NewGatePaths $OutDir $gateId $receiptId
$tsUtc = VF-NowUtc

# Deterministic reason collection (objects + stable string form)
$reasons = @()
function Add-Reason([string]$Code, [string]$Target, [string]$RelPath, [string]$Detail, [string]$Computed, [string]$Expected){
  $reasons += [ordered]@{
    code = $Code
    target = $Target
    rel_path = $RelPath
    detail = $Detail
    computed = $Computed
    expected = $Expected
  }
}

# Canonical sidecar paths
$zipShaFile = ($ZipPath + ".sha256")
$manFile    = ([IO.Path]::ChangeExtension($ZipPath, ".manifest.json"))
$manShaFile = ([IO.Path]::ChangeExtension($ZipPath, ".manifest.sha256"))

# Presence checks (fail-closed)
if(-not (Test-Path -LiteralPath $ZipPath -PathType Leaf)){
  Add-Reason "FAIL_MISSING_INPUT" "zip" $ZipPath "zip missing" $null $null
}
if(-not (Test-Path -LiteralPath $zipShaFile -PathType Leaf)){
  Add-Reason "FAIL_MISSING_INPUT" "zip_sha256_file" $zipShaFile "zip.sha256 missing" $null $null
}
if(-not (Test-Path -LiteralPath $manFile -PathType Leaf)){
  Add-Reason "FAIL_MISSING_INPUT" "manifest" $manFile "manifest.json missing" $null $null
}
if(-not (Test-Path -LiteralPath $manShaFile -PathType Leaf)){
  Add-Reason "FAIL_MISSING_INPUT" "manifest_sha256_file" $manShaFile "manifest.sha256 missing" $null $null
}

# Integrity checks
$zipC=$null; $zipE=$null; $manC=$null; $manE=$null

if(Test-Path -LiteralPath $ZipPath -PathType Leaf){
  $zipC = VF-Sha256 $ZipPath
  if(-not $zipC){ Add-Reason "FAIL_SCHEMA_INVALID" "zip" $ZipPath "zip sha256 compute failed" $null $null }
}
if(Test-Path -LiteralPath $zipShaFile -PathType Leaf){
  $zipE = VF-ReadFirstSha $zipShaFile
  if(-not $zipE){ Add-Reason "FAIL_SCHEMA_INVALID" "zip_sha256_file" $zipShaFile "zip.sha256 parse failed" $null $null }
}
if($zipC -and $zipE -and ($zipC -ne $zipE)){
  Add-Reason "FAIL_SHA256_MISMATCH" "zip" $ZipPath "zip sha mismatch" $zipC $zipE
}

if(Test-Path -LiteralPath $manFile -PathType Leaf){
  $manC = VF-Sha256 $manFile
  if(-not $manC){ Add-Reason "FAIL_SCHEMA_INVALID" "manifest" $manFile "manifest sha256 compute failed" $null $null }
}
if(Test-Path -LiteralPath $manShaFile -PathType Leaf){
  $manE = VF-ReadFirstSha $manShaFile
  if(-not $manE){ Add-Reason "FAIL_SCHEMA_INVALID" "manifest_sha256_file" $manShaFile "manifest.sha256 parse failed" $null $null }
}
if($manC -and $manE -and ($manC -ne $manE)){
  Add-Reason "FAIL_SHA256_MISMATCH" "manifest" $manFile "manifest sha mismatch" $manC $manE
}

# Manifest semantic checks (only after sha binding passes; do not parse untrusted manifest bytes)
if($manC -and $manE -and ($manC -eq $manE)){
  try {
    $m = Get-Content -LiteralPath $manFile -Raw -ErrorAction Stop | ConvertFrom-Json -ErrorAction Stop
    # Minimal contract: required fields exist
    if(-not $m.schema_version){ Add-Reason "FAIL_SCHEMA_INVALID" "manifest" $manFile "missing schema_version" $null $null }
    if(-not $m.kind){ Add-Reason "FAIL_SCHEMA_INVALID" "manifest" $manFile "missing kind" $null $null }
    if(-not $m.zip){ Add-Reason "FAIL_SCHEMA_INVALID" "manifest" $manFile "missing zip" $null $null }
    if(-not $m.entries){ Add-Reason "FAIL_SCHEMA_INVALID" "manifest" $manFile "missing entries" $null $null }

    # Policy: manifest.zip must bind to the zip file name (not a path)
    $leaf = (Split-Path -Leaf $ZipPath)
    if($m.zip -and ($m.zip.ToString() -ne $leaf)){
      Add-Reason "FAIL_POLICY_VIOLATION" "manifest.zip" $manFile ("manifest.zip != zip leaf (expected={0} actual={1})" -f $leaf,$m.zip) $null $null
    }
  } catch {
    Add-Reason "FAIL_SCHEMA_INVALID" "manifest" $manFile ("invalid manifest json: {0}" -f $_.Exception.Message) $null $null
  }
}

# Deterministic sorting (code, target, rel_path)
$reasons = @($reasons | Sort-Object code, target, rel_path)

$reason_codes = @()
if($reasons.Count -gt 0){
  $reason_codes = @($reasons | Select-Object -ExpandProperty code | Sort-Object -Unique)
}

$status = if($reason_codes.Count -gt 0){ "FAIL" } else { "PASS" }

$doc = [ordered]@{
  schema_version = 1
  kind = $gateId
  created_utc = $tsUtc
  status = $status
  reason_codes = @($reason_codes)
  reasons = @($reasons)
  inputs = [ordered]@{
    zip = $ZipPath
    zip_sha256_file = $zipShaFile
    manifest = $manFile
    manifest_sha256_file = $manShaFile
    out_dir = $OutDir
  }
  sha = [ordered]@{
    zip = [ordered]@{ computed = $zipC; expected = $zipE }
    manifest = [ordered]@{ computed = $manC; expected = $manE }
  }
}

VF-WriteJson $p.outJson $doc 80

$txt = @()
$txt += $gateId
$txt += "created_utc=$tsUtc"
$txt += "status=$status"
$txt += "zip=$ZipPath"
$txt += "zip_sha256_computed=$zipC"
$txt += "zip_sha256_expected=$zipE"
$txt += "manifest=$manFile"
$txt += "manifest_sha256_computed=$manC"
$txt += "manifest_sha256_expected=$manE"
if($reason_codes.Count -gt 0){
  $txt += ""
  $txt += "reason_codes:"
  foreach($c in @($reason_codes)){ $txt += ("  - " + $c) }
}
VF-WriteText $p.outTxt ($txt -join "`n")

$outs = [ordered]@{
  txt = $p.outTxt
  json = $p.outJson
  txt_sha256 = (VF-Sha256 $p.outTxt)
  json_sha256 = (VF-Sha256 $p.outJson)
}
VF-EmitReceipt $p.outRcpt "receipt_gate" $status @{ zip=$ZipPath; out_dir=$OutDir } $outs

if($status -ne "PASS"){
  Write-Host ("FAIL: {0} txt={1} json={2} receipt={3}" -f $gateId,$p.outTxt,$p.outJson,$p.outRcpt)
  exit 2
}
Write-Host ("PASS: {0} txt={1} json={2} receipt={3}" -f $gateId,$p.outTxt,$p.outJson,$p.outRcpt)
exit 0
