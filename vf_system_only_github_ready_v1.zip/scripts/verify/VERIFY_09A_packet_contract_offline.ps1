param(
  [Parameter(Mandatory=$true)][string]$ZipPath,
  [Parameter(Mandatory=$false)][string]$OutDir = "."
)
Set-StrictMode -Version Latest
$ErrorActionPreference="Stop"

. (Join-Path $PSScriptRoot "..\lib\VF_LIB.ps1")
. (Join-Path $PSScriptRoot "..\lib\VF_CONTRACTS.ps1")

$gateId = "VERIFY_09A_packet_contract_offline"
$receiptId = "verify_09A_packet_contract_offline"

VF-EnsureDir $OutDir
$OutDir = (Resolve-Path -LiteralPath $OutDir).Path
$p = VF-NewGatePaths $OutDir $gateId $receiptId
$tsUtc = VF-NowUtc

$tmpRoot = Join-Path $OutDir "artifacts/_tmp_contract_verify"
$val = VF-ValidateEvidencePacketZip $ZipPath $tmpRoot

# Normalize reasons -> reason codes
$reasons = @()
$codes = @()
if($val -and $val.reasons){
  foreach($r in @($val.reasons)){
    $code = $null
    if($r -match '^([A-Z0-9_-]+)'){
      $code = $Matches[1]
    } else {
      $code = "FAIL_SCHEMA_INVALID"
    }
    $codes += $code
    $reasons += [ordered]@{
      code = $code
      detail = $r
    }
  }
}

$reason_codes = @()
if($codes.Count -gt 0){
  $reason_codes = @($codes | Sort-Object -Unique)
}

$status = "PASS"
if(-not $val){ $status = "FAIL" }
elseif($val.status -ne "PASS"){ $status = "FAIL" }
elseif($reason_codes.Count -gt 0){ $status = "FAIL" }

$doc = [ordered]@{
  schema_version = 1
  kind = $gateId
  created_utc = $tsUtc
  status = $status
  reason_codes = @($reason_codes)
  reasons = @($reasons)
  inputs = [ordered]@{
    zip = $ZipPath
    out_dir = $OutDir
  }
}

VF-WriteJson $p.outJson $doc 80

$txt = @()
$txt += $gateId
$txt += "created_utc=$tsUtc"
$txt += "status=$status"
$txt += "zip=$ZipPath"
if($reason_codes.Count -gt 0){
  $txt += ""
  $txt += "reason_codes:"
  foreach($c in @($reason_codes)){ $txt += ("  - " + $c) }
}
VF-WriteText $p.outTxt ($txt -join "`n")

$outs = [ordered]@{
  txt = $p.outTxt
  json = $p.outJson
  txt_sha256 = (VF-Sha256 $p.outTxt)
  json_sha256 = (VF-Sha256 $p.outJson)
}
VF-EmitReceipt $p.outRcpt "receipt_verifier" $status @{ zip=$ZipPath; out_dir=$OutDir } $outs

if($status -ne "PASS"){ exit 2 }
exit 0
