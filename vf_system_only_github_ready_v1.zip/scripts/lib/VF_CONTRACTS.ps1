function VF-ValidateEvidencePacketZip([string]$ZipPath, [string]$TempRoot) {
  $reasons = New-Object System.Collections.Generic.List[string]
  $status = "PASS"

  function Fail([string]$Reason) {
    $script:status = "FAIL"
    $reasons.Add($Reason) | Out-Null
  }

  if(-not (Test-Path -LiteralPath $ZipPath -PathType Leaf)) { Fail ("FAIL_MISSING_INPUT: zip missing: {0}" -f $ZipPath) }

  if($script:status -eq "PASS") {
    VF-EnsureDir $TempRoot
    $work = Join-Path $TempRoot ([IO.Path]::GetRandomFileName())
    VF-EnsureDir $work
    try {
      try {
        VF-SafeExpandArchive -ZipPath $ZipPath -DestinationPath $work -Force
      } catch {
        Fail ("FAIL_POLICY_VIOLATION: unsafe_zip_expand: {0}" -f $_.Exception.Message)
      }
    } catch {
      Fail ("FAIL_SCHEMA_INVALID: cannot expand zip: {0}" -f $_.Exception.Message)
    }

    $required = @(
      "evidence_packet.json",
      "decision_record.json",
      "trust_root_bundle.json",
      "sarif/results.sarif",
      "packet.manifest.json"
    )

    foreach($r in $required) {
      $p = Join-Path $work $r
      if(-not (Test-Path -LiteralPath $p -PathType Leaf)) {
        Fail ("FAIL_MISSING_INPUT: missing required file in packet: {0}" -f $r)
      }
    }

    # Validate JSON parse for required JSON files
    foreach($j in @("evidence_packet.json","decision_record.json","trust_root_bundle.json","packet.manifest.json")) {
      $p = Join-Path $work $j
      if(Test-Path -LiteralPath $p -PathType Leaf) {
        try { Get-Content -LiteralPath $p -Raw -ErrorAction Stop | ConvertFrom-Json -ErrorAction Stop | Out-Null }
        catch { Fail ("FAIL_SCHEMA_INVALID: invalid json: {0}" -f $j) }
      }
    }

    # Manifest digest binding: packet_id must equal sha256(packet.manifest.json bytes)
    $epPath = Join-Path $work "evidence_packet.json"
    $manPath = Join-Path $work "packet.manifest.json"
    if($script:status -eq "PASS" -and (Test-Path -LiteralPath $epPath) -and (Test-Path -LiteralPath $manPath)) {
      $ep = Get-Content -LiteralPath $epPath -Raw | ConvertFrom-Json
      $manSha = VF-Sha256 $manPath
      if(-not $ep.packet_id) { Fail "FAIL_SCHEMA_INVALID: evidence_packet.json missing packet_id" }
      elseif($manSha -ne ($ep.packet_id.ToString().ToLowerInvariant())) { Fail "FAIL_POLICY_VIOLATION: packet_id does not match manifest sha256" }
    }

    # Trust staleness/expiry (fail-closed)
    $tbPath = Join-Path $work "trust_root_bundle.json"
    if($script:status -eq "PASS" -and (Test-Path -LiteralPath $tbPath)) {
      $tb = Get-Content -LiteralPath $tbPath -Raw | ConvertFrom-Json
      try {
        $issued = [DateTime]::Parse($tb.bundle_issued_utc).ToUniversalTime()
        $expires = [DateTime]::Parse($tb.bundle_expires_utc).ToUniversalTime()
        $maxStale = [int]$tb.max_staleness_days
        $now = (Get-Date).ToUniversalTime()
        if($expires -lt $now) { Fail "FAIL_TRUST_BUNDLE_STALE: bundle expired" }
        $staleDays = [Math]::Floor(($now - $issued).TotalDays)
        if($staleDays -gt $maxStale) { Fail "FAIL_TRUST_BUNDLE_STALE: bundle stale" }
      } catch {
        Fail "FAIL_SCHEMA_INVALID: invalid trust bundle fields"
      }
    }
  }

  return [ordered]@{
    status = $status
    reasons = @($reasons)
  }
}
