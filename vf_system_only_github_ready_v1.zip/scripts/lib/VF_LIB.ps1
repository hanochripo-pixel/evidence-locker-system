Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

# -----------------------------
# Time / filesystem primitives
# -----------------------------
function VF-NowUtc() {
  (Get-Date).ToUniversalTime().ToString("yyyy-MM-ddTHH:mm:ssZ")
}

function VF-EnsureDir([string]$Dir) {
  if($Dir -and -not (Test-Path -LiteralPath $Dir -PathType Container)) {
    New-Item -ItemType Directory -Force -Path $Dir | Out-Null
  }
}

function VF-Sha256([string]$Path) {
  if(-not (Test-Path -LiteralPath $Path -PathType Leaf)) { return $null }
  try { (Get-FileHash -Algorithm SHA256 -LiteralPath $Path).Hash.ToLowerInvariant() }
  catch { return $null }
}

function VF-ReadFirstSha([string]$Path) {
  if(-not (Test-Path -LiteralPath $Path -PathType Leaf)) { return $null }
  try {
    $l = (Get-Content -LiteralPath $Path -TotalCount 1 -ErrorAction Stop)
    if($l -match "^[0-9a-fA-F]{64}"){ return $matches[0].ToLowerInvariant() }
  } catch { return $null }
  return $null
}

# -----------------------------
# Canonical output writers
# -----------------------------
function VF-WriteText([string]$Path, [string]$Text) {
  VF-EnsureDir (Split-Path -Parent $Path)
  $t = ($Text -replace "`r`n","`n") -replace "`r","`n"
  if(-not $t.EndsWith("`n")) { $t += "`n" }
  [IO.File]::WriteAllText([IO.Path]::GetFullPath($Path), $t, (New-Object Text.UTF8Encoding($false)))
}

function VF-WriteJson([string]$Path, $Obj, [int]$Depth = 40) {
  $json = $Obj | ConvertTo-Json -Depth $Depth
  VF-WriteText $Path $json
}

function VF-NewGatePaths([string]$RepoRoot, [string]$GateId, [string]$ReceiptId) {
  $logs = Join-Path $RepoRoot "logs"
  $rcpts = Join-Path $RepoRoot "receipts"
  VF-EnsureDir $logs
  VF-EnsureDir $rcpts
  return [ordered]@{
    outTxt  = (Join-Path $logs  ("{0}.latest.txt"  -f $GateId))
    outJson = (Join-Path $logs  ("{0}.latest.json" -f $GateId))
    outRcpt = (Join-Path $rcpts ("{0}.latest.json" -f $ReceiptId))
  }
}

function VF-EmitReceipt([string]$Path, [string]$Kind, [string]$Status, $Inputs, $Outputs) {
  $rcpt = [ordered]@{
    schema_version = 1
    kind = $Kind
    created_utc = (VF-NowUtc)
    status = $Status
    inputs = $Inputs
    outputs = $Outputs
  }
  VF-WriteJson $Path $rcpt 60
}

# -----------------------------
# Back-compat aliases (seed v1)
# -----------------------------
function Ensure-Dir([string]$Dir){ VF-EnsureDir $Dir }
function Sha256([string]$Path){ VF-Sha256 $Path }
function ReadFirstSha([string]$Path){ VF-ReadFirstSha $Path }
function WriteTextLF([string]$Path,[string]$Text){ VF-WriteText $Path $Text }
function WriteJson([string]$Path,$Obj,[int]$Depth=40){ VF-WriteJson $Path $Obj $Depth }

function VF-SafeExpandArchive(
  [Parameter(Mandatory=$true)][string]$ZipPath,
  [Parameter(Mandatory=$true)][string]$DestinationPath,
  [Parameter(Mandatory=$false)][int]$MaxFiles = 2048,
  [Parameter(Mandatory=$false)][long]$MaxTotalUncompressedBytes = 268435456,
  [Parameter(Mandatory=$false)][long]$MaxSingleFileBytes = 67108864,
  [Parameter(Mandatory=$false)][switch]$Force
){
  Set-StrictMode -Version Latest
  $ErrorActionPreference = "Stop"

  if(-not (Test-Path -LiteralPath $ZipPath -PathType Leaf)){
    throw ("zip_missing:{0}" -f $ZipPath)
  }

  VF-EnsureDir $DestinationPath

  Add-Type -AssemblyName System.IO.Compression.FileSystem | Out-Null

  $zip = [System.IO.Compression.ZipFile]::OpenRead($ZipPath)
  $fileCount = 0
  [long]$total = 0

  try{
    $destFull = [System.IO.Path]::GetFullPath($DestinationPath)
    $sep = [System.IO.Path]::DirectorySeparatorChar
    if(-not $destFull.EndsWith([string]$sep)){ $destFull = $destFull + $sep }

    foreach($e in $zip.Entries){
      $name = $e.FullName
      if([string]::IsNullOrEmpty($name)){ continue }

      $norm = $name.Replace("\","/")

      # Absolute-path guard (/, \, or drive prefix like C:/)
      if($norm.StartsWith("/") -or $norm.StartsWith("\") -or ($norm -match "^[A-Za-z]:/")){
        throw ("zip_entry_absolute_path:{0}" -f $name)
      }

      # Normalize target path and ensure it stays under destination (zip-slip guard)
      $target = Join-Path $DestinationPath $norm
      $targetFull = [System.IO.Path]::GetFullPath($target)

      if(-not $targetFull.StartsWith($destFull, [System.StringComparison]::OrdinalIgnoreCase)){
        throw ("zip_entry_path_traversal:{0}" -f $name)
      }

      $fileCount++
      if($fileCount -gt $MaxFiles){
        throw ("zip_too_many_files:{0}" -f $fileCount)
      }

      [long]$len = 0
      try { $len = [long]$e.Length } catch { $len = 0 }

      if($len -gt $MaxSingleFileBytes){
        throw ("zip_entry_too_large:{0}:{1}" -f $name,$len)
      }

      $total += $len
      if($total -gt $MaxTotalUncompressedBytes){
        throw ("zip_total_uncompressed_too_large:{0}" -f $total)
      }
    }
  } finally {
    $zip.Dispose()
  }

  if($Force){
    Expand-Archive -LiteralPath $ZipPath -DestinationPath $DestinationPath -Force
  } else {
    Expand-Archive -LiteralPath $ZipPath -DestinationPath $DestinationPath
  }
}
