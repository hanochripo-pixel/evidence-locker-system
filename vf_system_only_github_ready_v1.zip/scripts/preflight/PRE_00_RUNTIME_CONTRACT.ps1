param(
  [Parameter(Mandatory=$false)][string]$RepoRoot = "."
)
Set-StrictMode -Version Latest
$ErrorActionPreference="Stop"

. (Join-Path $PSScriptRoot "..\lib\VF_LIB.ps1")

$gateId = "PRE_00_RUNTIME_CONTRACT"
$receiptId = "pre_00_runtime_contract"

# Always write artifacts under RepoRoot (even if the check itself is runtime-only)
$RepoRoot = (Resolve-Path -LiteralPath $RepoRoot).Path
$p = VF-NewGatePaths $RepoRoot $gateId $receiptId
$ts = VF-NowUtc

$stop = New-Object System.Collections.Generic.List[string]
$status = "PASS"
function Fail([string]$Code, [string]$Detail){
  $script:status="FAIL"
  if($Detail){ $stop.Add(("{0}: {1}" -f $Code,$Detail)) | Out-Null }
  else { $stop.Add($Code) | Out-Null }
}

# Contract checks (minimal but strict)
$pwsh = $PSVersionTable.PSVersion
if(-not $pwsh){ Fail "FAIL_POLICY_VIOLATION" "PowerShell not detected" }
elseif($pwsh.Major -lt 7){ Fail "FAIL_POLICY_VIOLATION" ("pwsh >= 7 required (actual={0})" -f $pwsh) }

# Ensure core cmds exist
if($status -eq "PASS"){
  if(-not (Get-Command Get-FileHash -ErrorAction SilentlyContinue)){ Fail "FAIL_POLICY_VIOLATION" "Get-FileHash not available" }
  if(-not (Get-Command ConvertTo-Json -ErrorAction SilentlyContinue)){ Fail "FAIL_POLICY_VIOLATION" "ConvertTo-Json not available" }
}

# Normalize reason codes (stable)
$reason_codes = @()
if($stop.Count -gt 0){
  $reason_codes = @($stop | ForEach-Object { ($_ -split ":",2)[0] } | Sort-Object -Unique)
}

$doc = [ordered]@{
  schema_version = 1
  kind = $gateId
  created_utc = $ts
  status = $status
  reason_codes = $reason_codes
  stop_reasons = @($stop)
  metrics = [ordered]@{
    pwsh_version = $pwsh.ToString()
  }
}

VF-WriteJson $p.outJson $doc 60

$txt = @()
$txt += $gateId
$txt += "created_utc=$ts"
$txt += "status=$status"
$txt += ("pwsh_version={0}" -f $pwsh)
if($stop.Count -gt 0){
  $txt += ""
  $txt += "stop_reasons:"
  foreach($r in @($stop)){ $txt += ("  - " + $r) }
}
VF-WriteText $p.outTxt ($txt -join "`n")

$outs = [ordered]@{
  txt = $p.outTxt
  json = $p.outJson
  txt_sha256 = (VF-Sha256 $p.outTxt)
  json_sha256 = (VF-Sha256 $p.outJson)
}
VF-EmitReceipt $p.outRcpt "receipt_gate" $status @{ repo_root=$RepoRoot } $outs

if($status -ne "PASS"){ exit 2 }
exit 0
