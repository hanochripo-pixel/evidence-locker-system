param(
  [Parameter(Mandatory=$true)][string]$RepoRoot
)
Set-StrictMode -Version Latest
$ErrorActionPreference="Stop"

. (Join-Path $PSScriptRoot "..\lib\VF_LIB.ps1")

$gateId = "PRE_00"
$receiptId = "pre_00"
$RepoRoot = (Resolve-Path -LiteralPath $RepoRoot).Path
$p = VF-NewGatePaths $RepoRoot $gateId $receiptId
$ts = VF-NowUtc

$stop = New-Object System.Collections.Generic.List[string]
$status = "PASS"
function Fail([string]$Code, [string]$Detail){
  $script:status="FAIL"
  if($Detail){ $stop.Add(("{0}: {1}" -f $Code,$Detail)) | Out-Null }
  else { $stop.Add($Code) | Out-Null }
}

# Minimal repo preflight invariants
if(-not (Test-Path -LiteralPath $RepoRoot -PathType Container)){ Fail "FAIL_MISSING_INPUT" "RepoRoot missing/not a directory" }

# Ensure baseline directories exist (idempotent)
if($status -eq "PASS"){
  VF-EnsureDir (Join-Path $RepoRoot "logs")
  VF-EnsureDir (Join-Path $RepoRoot "receipts")
  VF-EnsureDir (Join-Path $RepoRoot "artifacts")
}

# Required core files (community baseline)
$required = @(
  "GateTable.md",
  "README.md",
  "LICENSE",
  "SECURITY.md",
  "CODE_OF_CONDUCT.md",
  "CONTRIBUTING.md"
)
foreach($r in $required){
  $full = Join-Path $RepoRoot $r
  if(-not (Test-Path -LiteralPath $full -PathType Leaf)){
    Fail "FAIL_MISSING_INPUT" ("missing required file: {0}" -f $r)
  }
}

$reason_codes = @()
if($stop.Count -gt 0){
  $reason_codes = @($stop | ForEach-Object { ($_ -split ":",2)[0] } | Sort-Object -Unique)
}

$doc = [ordered]@{
  schema_version = 1
  kind = $gateId
  created_utc = $ts
  status = $status
  reason_codes = $reason_codes
  stop_reasons = @($stop)
  metrics = [ordered]@{
    required_files = $required.Count
  }
}

VF-WriteJson $p.outJson $doc 60

$txt = @()
$txt += $gateId
$txt += "created_utc=$ts"
$txt += "status=$status"
$txt += ("required_files={0}" -f $required.Count)
if($stop.Count -gt 0){
  $txt += ""
  $txt += "stop_reasons:"
  foreach($r in @($stop)){ $txt += ("  - " + $r) }
}
VF-WriteText $p.outTxt ($txt -join "`n")

$outs = [ordered]@{
  txt = $p.outTxt
  json = $p.outJson
  txt_sha256 = (VF-Sha256 $p.outTxt)
  json_sha256 = (VF-Sha256 $p.outJson)
}
VF-EmitReceipt $p.outRcpt "receipt_gate" $status @{ repo_root=$RepoRoot } $outs

if($status -ne "PASS"){ exit 2 }
exit 0
