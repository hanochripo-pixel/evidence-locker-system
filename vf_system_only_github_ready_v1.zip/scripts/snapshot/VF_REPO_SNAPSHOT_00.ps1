param(
  [Parameter(Mandatory=$true)][string]$RepoRoot
)
Set-StrictMode -Version Latest
$ErrorActionPreference="Stop"

. (Join-Path $PSScriptRoot "..\lib\VF_LIB.ps1")

$gateId = "VF_REPO_SNAPSHOT_00"
$receiptId = "vf_repo_snapshot_00"
$RepoRoot = (Resolve-Path -LiteralPath $RepoRoot).Path
$p = VF-NewGatePaths $RepoRoot $gateId $receiptId
$tsUtc = VF-NowUtc

$stop = New-Object System.Collections.Generic.List[string]
$status = "PASS"
function Fail([string]$Code, [string]$Detail){
  $script:status="FAIL"
  if($Detail){ $stop.Add(("{0}: {1}" -f $Code,$Detail)) | Out-Null }
  else { $stop.Add($Code) | Out-Null }
}

# Snapshot output (timestamped, immutable)
$tsStamp = (Get-Date).ToUniversalTime().ToString("yyyyMMddTHHmmssZ")
$outDir = Join-Path $RepoRoot "artifacts/repo_snapshot"
VF-EnsureDir $outDir
$snapPath = Join-Path $outDir ("VF_REPO_SNAPSHOT.{0}.json" -f $tsStamp)
$snapShaFile = ($snapPath + ".sha256")

# Enumerate repo files (exclude mutable dirs)
$files = Get-ChildItem -LiteralPath $RepoRoot -Recurse -File |
  Where-Object {
    $_.FullName -notmatch "\\\\(logs|receipts|artifacts|backups)\\\\"
  } |
  Sort-Object FullName

$entries = @()
foreach($f in $files){
  $rel = $f.FullName.Substring($RepoRoot.Length).TrimStart('\','/')
  $entries += [ordered]@{
    path  = ($rel -replace "\\\\","/")
    sha256 = (VF-Sha256 $f.FullName)
    bytes = [int64]$f.Length
  }
}

# Build snapshot doc
$snapDoc = [ordered]@{
  schema_version = 1
  kind = "VF_REPO_SNAPSHOT"
  created_utc = $tsUtc
  repo_root = $RepoRoot
  file_count = $entries.Count
  files = @($entries)
}

VF-WriteJson $snapPath $snapDoc 120
VF-WriteText $snapShaFile (("{0}  {1}" -f (VF-Sha256 $snapPath), (Split-Path -Leaf $snapPath)))

$reason_codes = @()
if($stop.Count -gt 0){
  $reason_codes = @($stop | ForEach-Object { ($_ -split ":",2)[0] } | Sort-Object -Unique)
}

$doc = [ordered]@{
  schema_version = 1
  kind = $gateId
  created_utc = $tsUtc
  status = $status
  reason_codes = $reason_codes
  stop_reasons = @($stop)
  outputs = [ordered]@{
    snapshot = $snapPath
    snapshot_sha256 = (VF-Sha256 $snapPath)
    snapshot_sha256_file = $snapShaFile
    snapshot_sha256_file_sha256 = (VF-Sha256 $snapShaFile)
  }
  metrics = [ordered]@{
    file_count = $entries.Count
  }
}

VF-WriteJson $p.outJson $doc 80
VF-WriteText $p.outTxt ("{0}`ncreated_utc={1}`nstatus={2}`nfile_count={3}`nsnapshot={4}" -f $gateId,$tsUtc,$status,$entries.Count,$snapPath)

$outs = [ordered]@{
  txt = $p.outTxt
  json = $p.outJson
  snapshot = $snapPath
  snapshot_sha256 = (VF-Sha256 $snapPath)
  snapshot_sha256_file = $snapShaFile
  txt_sha256 = (VF-Sha256 $p.outTxt)
  json_sha256 = (VF-Sha256 $p.outJson)
}
VF-EmitReceipt $p.outRcpt "receipt_gate" $status @{ repo_root=$RepoRoot } $outs

if($status -ne "PASS"){ exit 2 }
exit 0
