## Intent
What does this change do?

## Touched Paths
List files/directories changed.

## Evidence
- Which gates were run?
- Which receipts/artifacts prove correctness?

## Risk
What could break and how would we detect it?
